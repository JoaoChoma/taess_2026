import os, sys, glob, json, zipfile
import numpy as np
import pandas as pd

DOWNLOADS = "/working_dir/c_437f55c4f6d2d292/downloads"
WORK_DIR = "/working_dir/c_437f55c4f6d2d292/work_jpetstore"
SCRIPT_DIR = os.path.join(WORK_DIR, "script_oficial")
JP_REF_DIR = os.path.join(WORK_DIR, "taess_2026-912eb74cb8fa1839a49fac7f84d8c080f3cede8e/estudos_experimentais/helio_dacio/dataset/jpetclinic")
OUT_ARTIFACTS = "/working_dir/c_437f55c4f6d2d292/artifacts/file_generation/ttl=63d/output"
os.makedirs(OUT_ARTIFACTS, exist_ok=True)

zips = sorted(glob.glob(os.path.join(DOWNLOADS, "study_pg20261017585__P1-Reflective-Architect__config_*__jpetstore__execution_*.zip")))
print(f"Total ZIPs found in downloads: {len(zips)}")

# 1. Organize ZIPs using official organizar_zip.py
os.system(f"python3 {SCRIPT_DIR}/organizar_zip.py --src {DOWNLOADS} --dst {WORK_DIR}/dados_organizados")

# 2. Run official test suite and pipeline
print("\n--- Running official pytest suite ---")
os.system(f"cd {SCRIPT_DIR} && python3 -m pytest tests -q")

print("\n--- Running official analise_estudo pipeline (group-by persona) ---")
os.system(f"cd {SCRIPT_DIR} && python3 -m analise_estudo --root {WORK_DIR}/dados_organizados --out {WORK_DIR}/resultados_reproduzidos --group-by persona")

# 3. Compare reproduced CSV and JSON with reference CSV and JSON
ref_csv = pd.read_csv(os.path.join(JP_REF_DIR, "P1-Reflective-Architect_jpetstore.csv"))
rep_csv_path = glob.glob(os.path.join(WORK_DIR, "resultados_reproduzidos/por_sistema/*.csv"))[0]
rep_csv = pd.read_csv(rep_csv_path)

ref_json = json.load(open(os.path.join(JP_REF_DIR, "P1-Reflective-Architect_jpetstore.json")))
rep_json_path = glob.glob(os.path.join(WORK_DIR, "resultados_reproduzidos/por_sistema/*.json"))[0]
rep_json = json.load(open(rep_json_path))

print("\n--- Reconciliation between Official Pipeline Reproduction and Reference CSV/JSON ---")
merged = pd.merge(ref_csv, rep_csv, on=["config", "repeticao"], suffixes=("_ref", "_rep"))
for col in ["geracao", "n_pontos", "n_duplicados", "hv", "igd_plus", "ed_media", "ed_min", "spacing"]:
    diff = np.abs(merged[f"{col}_ref"] - merged[f"{col}_rep"]).max()
    print(f"Max abs diff for {col:12s}: {diff:.3e}")

z_ref = np.array(ref_json["fronteira_referencia"])
z_rep = np.array(rep_json["fronteira_referencia"])
print(f"Reference Z* shape: {z_ref.shape}, Reproduced Z* shape: {z_rep.shape}, Max diff: {np.abs(z_ref - z_rep).max():.3e}")

# 4. Detailed Audit of Bloco A, Bloco B presence, Bloco C, Bloco D across all 40 ZIPs
IDS = [
    'nsgaiii__elit_on__penalty', 'nsgaiii__elit_off__penalty',
    'rnsgaiii__elit_on__penalty', 'rnsgaiii__elit_off__penalty',
    'nsgaiii__elit_on__kill', 'nsgaiii__elit_off__kill',
    'rnsgaiii__elit_on__kill', 'rnsgaiii__elit_off__kill'
]
CFG_MAP = {c: f"C{i+1}" for i, c in enumerate(IDS)}

expected_files = [
    "manifest.json", "parameters.json", "timing.json", "anomalies.json",
    "decisions.json", "interactions.json", "behavioral_events.json", "intent_diffusion.json",
    "candidates.json", "bestSolutions.json", "frontiers.json", "indicators.json"
]

rows = []
params_summary = set()
zstar_set = set(map(tuple, np.round(z_ref, 12)))
lim_min = np.array(ref_json["limites_normalizacao"]["min"])
lim_max = np.array(ref_json["limites_normalizacao"]["max"])

for zpath in zips:
    with zipfile.ZipFile(zpath, "r") as zf:
        names = set(zf.namelist())
        missing = [f for f in expected_files if f not in names]
        manifest = json.loads(zf.read("manifest.json"))
        params = json.loads(zf.read("parameters.json"))
        timing = json.loads(zf.read("timing.json"))
        anomalies = json.loads(zf.read("anomalies.json")) if "anomalies.json" in names else {}
        frontiers = json.loads(zf.read("frontiers.json"))
        decisions = json.loads(zf.read("decisions.json"))
        interactions = json.loads(zf.read("interactions.json"))

        cfg_id = manifest["study"]["configId"]
        rep = manifest["study"]["repetition"]
        c_short = CFG_MAP[cfg_id]

        # Check raw frontier
        raw_pts = np.array(frontiers["frontier"], dtype=float)
        n_raw = len(raw_pts)
        # Check penalized (>= 1e5)
        pen_mask = (raw_pts >= 1e5).any(axis=1)
        n_penalized = int(pen_mask.sum())
        valid_pts = raw_pts[~pen_mask]
        unique_pts = np.unique(valid_pts, axis=0)
        n_unique = len(unique_pts)
        n_dup = len(valid_pts) - n_unique

        # Check how many points of this run belong to Z*
        norm_pts = (unique_pts - lim_min) / (lim_max - lim_min)
        in_zstar = sum(1 for pt in map(tuple, np.round(norm_pts, 12)) if pt in zstar_set)

        # Timing
        active_ms = timing.get("activeTimeMs", timing.get("activeMs", 0))
        paused_ms = timing.get("pausedTimeMs", timing.get("pausedMs", 0))
        wall_ms = timing.get("wallTimeMs", timing.get("wallMs", 0))
        gpm = timing.get("generationsPerMinute", 0)
        stop_reason = timing.get("stopReason", "")

        # Anomalies
        n_anomalies = anomalies.get("totalFallbacks", len(anomalies.get("records", anomalies.get("anomalies", [])))) if isinstance(anomalies, dict) else len(anomalies)

        # Params signature
        p_sig = json.dumps(params, sort_keys=True)
        params_summary.add((c_short, cfg_id, p_sig))

        # Get indicator values from merged
        m_row = merged[(merged["config"] == cfg_id) & (merged["repeticao"] == rep)].iloc[0]

        rows.append({
            "C": c_short,
            "config": cfg_id,
            "repeticao": rep,
            "participante": manifest["study"].get("participantCode", ""),
            "persona": manifest["study"].get("personaId", ""),
            "sistema": manifest["run"].get("sourceId", ""),
            "geracao_final": frontiers.get("generation", manifest["run"].get("generations")),
            "stop_reason": stop_reason,
            "n_brutos": n_raw,
            "n_penalizados": n_penalized,
            "n_pontos_unicos": n_unique,
            "n_duplicados": n_dup,
            "pts_em_Zstar": in_zstar,
            "active_s": active_ms / 1000.0,
            "paused_s": paused_ms / 1000.0,
            "wall_s": wall_ms / 1000.0,
            "gen_por_min": gpm,
            "n_anomalias": n_anomalies,
            "n_interacoes_dec": len(decisions) if isinstance(decisions, list) else len(decisions.get("decisions", [])),
            "hv": m_row["hv_ref"],
            "igd_plus": m_row["igd_plus_ref"],
            "ed_media": m_row["ed_media_ref"],
            "ed_min": m_row["ed_min_ref"],
            "spacing": m_row["spacing_ref"],
            "missing_files": ",".join(missing) if missing else "Nenhum"
        })

audit_df = pd.DataFrame(rows)
audit_df["c_num"] = audit_df["C"].str.slice(1).astype(int)
audit_df = audit_df.sort_values(["c_num", "repeticao"]).drop(columns=["c_num"]).reset_index(drop=True)
audit_df.to_csv(os.path.join(OUT_ARTIFACTS, "auditoria_execucoes_jpetstore.csv"), index=False)

print("\n--- Summary of Parameters per Configuration ---")
for c_short, cfg_id, p_sig in sorted(params_summary):
    print(f"{c_short} ({cfg_id}): {p_sig}")

print("\n--- Sample timing.json and anomalies.json keys ---")
with zipfile.ZipFile(zips[0], "r") as zf:
    print("timing.json:", json.loads(zf.read("timing.json")))
    print("anomalies.json:", json.loads(zf.read("anomalies.json")))
    print("manifest.json:", json.loads(zf.read("manifest.json")))

print("\n--- Audit Summary by Configuration ---")
grp = audit_df.groupby(["C", "config"], sort=False).agg(
    runs=("repeticao", "count"),
    n_brutos_mean=("n_brutos", "mean"),
    n_penalizados_sum=("n_penalizados", "sum"),
    n_unicos_mean=("n_pontos_unicos", "mean"),
    n_unicos_min=("n_pontos_unicos", "min"),
    n_unicos_max=("n_pontos_unicos", "max"),
    n_dup_mean=("n_duplicados", "mean"),
    n_dup_sum=("n_duplicados", "sum"),
    pts_Zstar_sum=("pts_em_Zstar", "sum"),
    active_min_mean=("active_s", lambda x: (x/60.0).mean()),
    paused_min_mean=("paused_s", lambda x: (x/60.0).mean()),
    wall_min_mean=("wall_s", lambda x: (x/60.0).mean()),
    anomalias_sum=("n_anomalias", "sum")
).reset_index()
print(grp.to_string(index=False))

print("\n--- Overall Timing Statistics (40 executions) ---")
for col, label in [("active_s", "Active Time"), ("paused_s", "Paused/DM Time"), ("wall_s", "Wall Time")]:
    s = audit_df[col]
    idx_min = s.idxmin()
    idx_max = s.idxmax()
    print(f"{label}: Mean={s.mean()/60:.2f} min ({int(s.mean()//60)}m{int(s.mean()%60):02d}s), Median={s.median()/60:.2f} min, Total={s.sum()/3600:.2f} h ({int(s.sum()//3600)}h{int((s.sum()%3600)//60):02d}m)")
    print(f"   Min: {s.min()/60:.2f} min ({int(s.min()//60)}m{int(s.min()%60):02d}s) in {audit_df.loc[idx_min, 'C']}-E{audit_df.loc[idx_min, 'repeticao']}")
    print(f"   Max: {s.max()/60:.2f} min ({int(s.max()//60)}m{int(s.max()%60):02d}s) in {audit_df.loc[idx_max, 'C']}-E{audit_df.loc[idx_max, 'repeticao']}")
