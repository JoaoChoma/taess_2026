import glob
import json
import os
import shutil
import zipfile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import numpy as np
import pandas as pd

OUT_DIR = "/working_dir/c_437f55c4f6d2d292/artifacts/file_generation/ttl=63d/output"
INTER_DIR = "/working_dir/c_437f55c4f6d2d292/artifacts/file_generation/ttl=63d/intermediate"
FIG_LATEX_DIR = "/working_dir/c_437f55c4f6d2d292/work_jpetstore/figuras"
os.makedirs(OUT_DIR, exist_ok=True)
os.makedirs(INTER_DIR, exist_ok=True)
os.makedirs(FIG_LATEX_DIR, exist_ok=True)

# Exact palette and style matching main.tex / artigo_maes2.pdf
NIVEIS = ["C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8"]
CONFIG_IDS = [
    "nsgaiii__elit_on__penalty",
    "nsgaiii__elit_off__penalty",
    "rnsgaiii__elit_on__penalty",
    "rnsgaiii__elit_off__penalty",
    "nsgaiii__elit_on__kill",
    "nsgaiii__elit_off__kill",
    "rnsgaiii__elit_on__kill",
    "rnsgaiii__elit_off__kill",
]
ID2CFG = dict(zip(CONFIG_IDS, NIVEIS))

COLORS = {
    "C1": "#1f77b4",
    "C2": "#e6612c",
    "C3": "#159e6d",
    "C4": "#e69f00",
    "C5": "#e377a8",
    "C6": "#008300",
    "C7": "#6250d6",
    "C8": "#dc4444",
}
LINESTYLES = {
    "C1": "-",
    "C2": "-",
    "C3": "-",
    "C4": "-",
    "C5": "--",
    "C6": "--",
    "C7": "--",
    "C8": "--",
}
MARKERS = {
    "C1": "o",
    "C2": "o",
    "C3": "s",
    "C4": "s",
    "C5": "o",
    "C6": "o",
    "C7": "s",
    "C8": "s",
}
LEGEND_LABELS = {
    "C1": "C1 NSGA-III el.ON PEN",
    "C2": "C2 NSGA-III el.OFF PEN",
    "C3": "R-NSGA-III el.ON PEN",
    "C4": "C4 R-NSGA-III el.OFF PEN",
    "C5": "C5 NSGA-III el.ON KILL",
    "C6": "C6 NSGA-III el.OFF KILL",
    "C7": "C7 R-NSGA-III el.ON KILL",
    "C8": "C8 R-NSGA-III el.OFF KILL",
}
# Fix C3 label to include C3 prefix
LEGEND_LABELS["C3"] = "C3 R-NSGA-III el.ON PEN"

PANEL_TITLES = {
    "C1": "(a) C1: NSGA-III, el. ON, PENALTY",
    "C2": "(b) C2: NSGA-III, el. OFF, PENALTY",
    "C3": "(c) C3: R-NSGA-III, el. ON, PENALTY",
    "C4": "(d) C4: R-NSGA-III, el. OFF, PENALTY",
    "C5": "(e) C5: NSGA-III, el. ON, KILL",
    "C6": "(f) C6: NSGA-III, el. OFF, KILL",
    "C7": "(g) C7: R-NSGA-III, el. ON, KILL",
    "C8": "(h) C8: R-NSGA-III, el. OFF, KILL",
}

EXEC_COLORS = ["#1f77b4", "#e6612c", "#159e6d", "#e69f00", "#6250d6"]

plt.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["DejaVu Sans", "Arial", "Helvetica"],
        "font.size": 9,
        "axes.titlesize": 9.5,
        "axes.labelsize": 9.5,
        "xtick.labelsize": 8.5,
        "ytick.labelsize": 8.5,
        "legend.fontsize": 8.5,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.edgecolor": "#444444",
        "axes.linewidth": 0.9,
        "grid.color": "#e2e2e2",
        "grid.linewidth": 0.6,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    }
)


def save_both(fig, stem):
    pdf_out = os.path.join(OUT_DIR, f"{stem}.pdf")
    png_out = os.path.join(OUT_DIR, f"{stem}.png")
    fig.savefig(pdf_out, bbox_inches="tight", facecolor="white")
    fig.savefig(png_out, dpi=300, bbox_inches="tight", facecolor="white")
    shutil.copy2(pdf_out, os.path.join(FIG_LATEX_DIR, f"{stem}.pdf"))
    shutil.copy2(png_out, os.path.join(FIG_LATEX_DIR, f"{stem}.png"))
    plt.close(fig)
    print(f"Saved {stem}.pdf and {stem}.png")


def generate_convergence_figures(df_conv):
    geracoes = [0, 600, 820, 950, 999]
    x_pos = np.arange(len(geracoes))
    obj_specs = [
        ("Coupling_min", "Acoplamento (melhor valor)", "convergencia_acoplamento", "(a) Acoplamento"),
        ("Cohesion_min", "Coesão (1/valor) (melhor valor)", "convergencia_coesao", "(b) Coesão (forma inversa)"),
        ("Overhead_min", "Overhead (melhor valor)", "convergencia_overhead", "(c) Overhead de rede"),
        ("Functionality_min", "Funcionalidade (1/valor) (melhor valor)", "convergencia_funcionalidade", "(d) Modularização de funcionalidades (forma inversa)"),
    ]

    # 1. Individual panels for LaTeX \subfloat
    for col, ylabel, stem, _ in obj_specs:
        fig, ax = plt.subplots(figsize=(4.2, 3.5))
        ax.grid(True, zorder=0)
        for cfg in NIVEIS:
            sub = df_conv[df_conv["config_code"] == cfg]
            means = [sub[sub["geracao"] == g][col].mean() for g in geracoes]
            ax.plot(
                x_pos,
                means,
                color=COLORS[cfg],
                linestyle=LINESTYLES[cfg],
                marker=MARKERS[cfg],
                markersize=5.5,
                linewidth=1.6,
                label=LEGEND_LABELS[cfg],
                zorder=4 if cfg in ["C1", "C2", "C3", "C4"] else 3,
            )
        ax.set_xticks(x_pos)
        ax.set_xticklabels([str(g) for g in geracoes])
        ax.set_xlabel("Geração")
        ax.set_ylabel(ylabel)
        save_both(fig, stem)

    # 2. Standalone legend (legenda_convergencia.pdf) matching main.tex
    fig_leg = plt.figure(figsize=(8.2, 0.65))
    handles = []
    # Arrange in 4 columns x 2 rows so each column has (C1, C2), (C3, C4), (C5, C6), (C7, C8)
    order_for_ncol4 = ["C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8"]
    for cfg in order_for_ncol4:
        h = mlines.Line2D(
            [],
            [],
            color=COLORS[cfg],
            linestyle=LINESTYLES[cfg],
            marker=MARKERS[cfg],
            markersize=5.5,
            linewidth=1.6,
            label=LEGEND_LABELS[cfg],
        )
        handles.append(h)
    fig_leg.legend(
        handles=handles,
        loc="center",
        ncol=4,
        frameon=False,
        columnspacing=1.4,
        handletextpad=0.5,
        handlelength=2.2,
    )
    save_both(fig_leg, "legenda_convergencia")

    # 3. Combined 2x2 figure with legend (convergencia_jpetstore.pdf) for direct inspection
    fig_all, axes = plt.subplots(2, 2, figsize=(9.2, 7.4))
    for ax, (col, ylabel, _, sub_title) in zip(axes.ravel(), obj_specs):
        ax.grid(True, zorder=0)
        for cfg in NIVEIS:
            sub = df_conv[df_conv["config_code"] == cfg]
            means = [sub[sub["geracao"] == g][col].mean() for g in geracoes]
            ax.plot(
                x_pos,
                means,
                color=COLORS[cfg],
                linestyle=LINESTYLES[cfg],
                marker=MARKERS[cfg],
                markersize=5.5,
                linewidth=1.6,
                label=LEGEND_LABELS[cfg],
                zorder=4 if cfg in ["C1", "C2", "C3", "C4"] else 3,
            )
        ax.set_xticks(x_pos)
        ax.set_xticklabels([str(g) for g in geracoes])
        ax.set_xlabel("Geração")
        ax.set_ylabel(ylabel)
        ax.set_title(sub_title, fontsize=9.5, pad=6)
    fig_all.legend(
        handles=handles,
        loc="lower center",
        ncol=4,
        frameon=False,
        bbox_to_anchor=(0.5, -0.02),
        columnspacing=1.4,
        handletextpad=0.5,
        handlelength=2.2,
    )
    fig_all.tight_layout(rect=(0, 0.05, 1, 1))
    save_both(fig_all, "convergencia_jpetstore")


def generate_parallel_coordinates(meta_json, df_frag):
    lim_min = np.array(meta_json["limites_normalizacao"]["min"], dtype=float)
    lim_max = np.array(meta_json["limites_normalizacao"]["max"], dtype=float)
    span = np.where(lim_max > lim_min, lim_max - lim_min, 1.0)
    zstar = np.array(meta_json["fronteira_referencia"], dtype=float)
    metric_names = meta_json["metric_names"]

    # Find the most domain-adherent final solution in JPetStore (C8-E5, 74.67% adherence, or C4-E4, 72.00%)
    sub_best_adh = df_frag[
        (df_frag["criterio_selecao"] == "Maior_Aderencia_Extremos") & (df_frag["geracao"] == 999)
    ].sort_values(["adh_pct", "cls_purity_pct"], ascending=False)
    top_adh_row = sub_best_adh.iloc[0]
    top_adh_raw = np.array([top_adh_row[m] for m in metric_names], dtype=float)
    top_adh_norm = np.clip((top_adh_raw - lim_min) / span, 0.0, 1.0)

    # Load all 40 frontiers
    zips = sorted(glob.glob("downloads/study_pg20261017585*.zip"))
    front_by_cfg_rep = {}
    for zpath in zips:
        with zipfile.ZipFile(zpath, "r") as z:
            manifest = json.loads(z.read("manifest.json").decode("utf-8"))
            cfg_num = int(zpath.split("__config_")[1].split("__")[0])
            rep = int(manifest["study"]["repetition"])
            fr = json.loads(z.read("frontiers.json").decode("utf-8"))
            arr = np.array(fr["frontier"], dtype=float)
            arr = arr[(arr < 1e5).all(axis=1)]
            arr = np.unique(arr, axis=0)
            arr_norm = (arr - lim_min) / span
            front_by_cfg_rep[(f"C{cfg_num}", rep)] = arr_norm

    x_axes = np.arange(5)
    x_labels = [
        "Acopl.",
        "Coes.$^{-1}$",
        "Overh.",
        "Func.$^{-1}$",
        "Reúso$^{-1}$",
    ]

    # 1. Combined 2x4 figure (paralelas_todas.pdf) matching Fig. 2 of main.tex
    fig, axes = plt.subplots(2, 4, figsize=(11.5, 5.2), sharey=True)
    for idx, cfg in enumerate(NIVEIS):
        ax = axes[idx // 4, idx % 4]
        # Background: Reference Pareto front Z*
        for row in zstar:
            ax.plot(x_axes, row, color="#d4d4d4", linewidth=0.45, alpha=0.55, zorder=1)
        # Foreground: 5 executions
        for rep in range(1, 6):
            arr_norm = front_by_cfg_rep[(cfg, rep)]
            for row in arr_norm:
                ax.plot(
                    x_axes,
                    row,
                    color=EXEC_COLORS[rep - 1],
                    linewidth=0.55,
                    alpha=0.48,
                    zorder=2 + rep * 0.1,
                )
        # Dotted black reference: Solução mais aderente ao domínio
        ax.plot(
            x_axes,
            top_adh_norm,
            color="#111111",
            linestyle=":",
            linewidth=1.8,
            zorder=8,
        )
        for x in x_axes:
            ax.axvline(x, color="#666666", linewidth=0.75, zorder=5)
        ax.set_xticks(x_axes)
        ax.set_xticklabels(x_labels, fontsize=7.8)
        ax.set_xlim(-0.12, 4.12)
        ax.set_ylim(-0.03, 1.03)
        ax.grid(True, axis="y", color="#e6e6e6", linewidth=0.5, zorder=0)
        ax.set_title(PANEL_TITLES[cfg], fontsize=8.2, pad=5)
        if idx % 4 == 0:
            ax.set_ylabel("Valor normalizado", fontsize=8.8)

    legend_handles = [
        mlines.Line2D([], [], color=EXEC_COLORS[i], linewidth=1.6, label=f"Execução {i+1}")
        for i in range(5)
    ]
    legend_handles.append(
        mlines.Line2D([], [], color="#bdbdbd", linewidth=1.4, label="Fronteira de referência Z*")
    )
    legend_handles.append(
        mlines.Line2D(
            [],
            [],
            color="#111111",
            linestyle=":",
            linewidth=1.8,
            label="Solução mais aderente ao domínio",
        )
    )
    fig.legend(
        handles=legend_handles,
        loc="lower center",
        ncol=7,
        frameon=False,
        bbox_to_anchor=(0.5, -0.02),
        columnspacing=1.2,
        handletextpad=0.5,
        fontsize=8.2,
    )
    fig.tight_layout(rect=(0, 0.05, 1, 1))
    save_both(fig, "paralelas_todas")

    # 2. Individual parallel coordinate figures (paralelas_C1..C8.pdf)
    for cfg in NIVEIS:
        fig_c, ax_c = plt.subplots(figsize=(4.4, 3.0))
        for row in zstar:
            ax_c.plot(x_axes, row, color="#d4d4d4", linewidth=0.5, alpha=0.6, zorder=1)
        for rep in range(1, 6):
            arr_norm = front_by_cfg_rep[(cfg, rep)]
            for row in arr_norm:
                ax_c.plot(
                    x_axes,
                    row,
                    color=EXEC_COLORS[rep - 1],
                    linewidth=0.6,
                    alpha=0.5,
                    zorder=2 + rep * 0.1,
                )
        ax_c.plot(x_axes, top_adh_norm, color="#111111", linestyle=":", linewidth=1.9, zorder=8)
        for x in x_axes:
            ax_c.axvline(x, color="#666666", linewidth=0.8, zorder=5)
        ax_c.set_xticks(x_axes)
        ax_c.set_xticklabels(x_labels, fontsize=8.5)
        ax_c.set_xlim(-0.12, 4.12)
        ax_c.set_ylim(-0.03, 1.03)
        ax_c.set_ylabel("Valor normalizado")
        ax_c.grid(True, axis="y", color="#e6e6e6", linewidth=0.5, zorder=0)
        save_both(fig_c, f"paralelas_{cfg}")


def plot_styled_boxplot(data_by_cfg, ylabel, stem, hline_val=None):
    fig, ax = plt.subplots(figsize=(4.5, 3.1))
    ax.grid(True, zorder=0)
    positions = np.arange(1, 9)
    groups = [data_by_cfg[cfg] for cfg in NIVEIS]

    bp = ax.boxplot(
        groups,
        positions=positions,
        widths=0.52,
        patch_artist=True,
        showfliers=False,
        medianprops={"color": "#111111", "linewidth": 1.5},
        whiskerprops={"color": "#444444", "linewidth": 1.1},
        capprops={"color": "#444444", "linewidth": 1.1, "linestyle": "--"},
        zorder=2,
    )
    for patch, cfg in zip(bp["boxes"], NIVEIS):
        patch.set_facecolor(COLORS[cfg] + "70")
        patch.set_edgecolor(COLORS[cfg])
        patch.set_linewidth(1.0)

    for x, cfg in zip(positions, NIVEIS):
        vals = data_by_cfg[cfg]
        ax.scatter(
            np.full(len(vals), x),
            vals,
            s=28,
            color=COLORS[cfg],
            edgecolor="white",
            linewidth=0.7,
            zorder=4,
        )

    ax.axvline(4.5, color="#555555", linestyle="--", linewidth=0.95, zorder=3)
    if hline_val is not None:
        ax.axhline(hline_val, color="#666666", linestyle=":", linewidth=1.0, zorder=3)

    ymin, ymax = ax.get_ylim()
    yrange = ymax - ymin
    ax.set_ylim(ymin - 0.02 * yrange, ymax + 0.10 * yrange)
    y_top = ymax + 0.035 * yrange
    ax.text(2.5, y_top, "PENALTY", ha="center", va="bottom", fontsize=8.8, color="#555555")
    ax.text(6.5, y_top, "KILL", ha="center", va="bottom", fontsize=8.8, color="#555555")

    ax.set_xticks(positions)
    ax.set_xticklabels(NIVEIS)
    ax.set_ylabel(ylabel)
    save_both(fig, stem)


def generate_indicator_and_rq2_figures(df_ind, df_frag):
    # 1. HV, IGD+, ED boxplots matching Fig. 3 of main.tex
    for col, ylabel, stem in [
        ("hv", "HV (maior é melhor)", "indicador_hv"),
        ("igd_plus", "IGD+ (menor é melhor)", "indicador_igd_plus"),
        ("ed_media", "ED média (menor é melhor)", "indicador_ed_media"),
    ]:
        data_by_cfg = {
            cfg: df_ind[df_ind["config"] == cfg_id][col].to_numpy()
            for cfg, cfg_id in zip(NIVEIS, CONFIG_IDS)
        }
        plot_styled_boxplot(data_by_cfg, ylabel, stem)

    # 2. Aderência ao gabarito de domínios (aderencia.pdf) matching Fig. 4 of main.tex
    sub_adh = df_frag[
        (df_frag["criterio_selecao"] == "Maior_Aderencia_Extremos") & (df_frag["geracao"] == 999)
    ]
    adh_by_cfg = {
        cfg: sub_adh[sub_adh["config_code"] == cfg]["adh_pct"].to_numpy() for cfg in NIVEIS
    }
    plot_styled_boxplot(adh_by_cfg, "Aderência ao gabarito (%)", "aderencia")

    # 3. Pureza / Concentração de classe (pureza_classe.pdf)
    cp_by_cfg = {
        cfg: sub_adh[sub_adh["config_code"] == cfg]["cls_purity_pct"].to_numpy() for cfg in NIVEIS
    }
    plot_styled_boxplot(cp_by_cfg, "Concentração por classe (%)", "pureza_classe")


def main():
    df_conv = pd.read_csv(os.path.join(OUT_DIR, "evolucao_fitness_geracoes_jpetstore.csv"))
    df_frag = pd.read_csv(os.path.join(OUT_DIR, "fragmentacao_arquitetural_rq2_jpetstore.csv"))
    df_ind = pd.read_csv(
        "work_jpetstore/taess_2026-912eb74cb8fa1839a49fac7f84d8c080f3cede8e/estudos_experimentais/helio_dacio/dataset/jpetclinic/P1-Reflective-Architect_jpetstore.csv"
    )
    meta_json = json.load(
        open(
            "work_jpetstore/taess_2026-912eb74cb8fa1839a49fac7f84d8c080f3cede8e/estudos_experimentais/helio_dacio/dataset/jpetclinic/P1-Reflective-Architect_jpetstore.json",
            encoding="utf-8",
        )
    )

    generate_convergence_figures(df_conv)
    generate_parallel_coordinates(meta_json, df_frag)
    generate_indicator_and_rq2_figures(df_ind, df_frag)


if __name__ == "__main__":
    main()
