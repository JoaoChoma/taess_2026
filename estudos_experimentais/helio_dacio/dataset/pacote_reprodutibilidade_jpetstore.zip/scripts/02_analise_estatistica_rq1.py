import os, zipfile, json
from itertools import combinations
import numpy as np
import pandas as pd
from scipy import stats

WORK_DIR = "/working_dir/c_437f55c4f6d2d292/work_jpetstore"
JP_REF_DIR = os.path.join(WORK_DIR, "taess_2026-912eb74cb8fa1839a49fac7f84d8c080f3cede8e/estudos_experimentais/helio_dacio/dataset/jpetclinic")
OUT_ARTIFACTS = "/working_dir/c_437f55c4f6d2d292/artifacts/file_generation/ttl=63d/output"
os.makedirs(OUT_ARTIFACTS, exist_ok=True)

# First, inspect the existing reference CSVs in helio_dacio/dataset/analise_descritiva/saida/
TAESS_ZIP = "/working_dir/c_437f55c4f6d2d292/user_uploaded_files/ttl=63d/user_uploaded/taess_2026"
with zipfile.ZipFile(TAESS_ZIP, "r") as zf:
    for fn in ["estatistica_descritiva.csv", "testes_resumo.csv", "testes_pares_posthoc_bh_a12.csv", "testes_fatores_a12.csv"]:
        path = f"taess_2026-912eb74cb8fa1839a49fac7f84d8c080f3cede8e/estudos_experimentais/helio_dacio/dataset/analise_descritiva/saida/{fn}"
        print(f"=== Reference {fn} (first 10 lines) ===")
        txt = zf.read(path).decode("utf-8")
        for line in txt.splitlines()[:10]:
            print("  ", line)

# Load validated JPetStore CSV
df = pd.read_csv(os.path.join(JP_REF_DIR, "P1-Reflective-Architect_jpetstore.csv"))
df = df[df["geracao"] == 999].copy()

IDS = [
    'nsgaiii__elit_on__penalty', 'nsgaiii__elit_off__penalty',
    'rnsgaiii__elit_on__penalty', 'rnsgaiii__elit_off__penalty',
    'nsgaiii__elit_on__kill', 'nsgaiii__elit_off__kill',
    'rnsgaiii__elit_on__kill', 'rnsgaiii__elit_off__kill'
]
CFG_MAP = {c: f"C{i+1}" for i, c in enumerate(IDS)}
df["C"] = df["config"].map(CFG_MAP)
niveis_C = [f"C{i}" for i in range(1, 9)]

# Official functions from notebooks/analise_estatistica.ipynb
def bh_fdr(pvals):
    p = np.asarray(pvals, dtype=float)
    ajustado = np.full(p.shape, np.nan, dtype=float)
    mask = np.isfinite(p)
    if mask.any():
        pf = p[mask]
        n = len(pf)
        ordem = np.argsort(pf)
        ranqueado = pf[ordem] * n / (np.arange(n) + 1)
        ranqueado = np.minimum.accumulate(ranqueado[::-1])[::-1]
        bloco = np.empty(n, dtype=float)
        bloco[ordem] = np.clip(ranqueado, 0.0, 1.0)
        ajustado[mask] = bloco
    return ajustado

def dunn_pairwise(valores, rotulos, niveis_local):
    valores = np.asarray(valores, dtype=float)
    rotulos = np.asarray(rotulos)
    N = len(valores)
    ranks = stats.rankdata(valores)
    _, contagens = np.unique(valores, return_counts=True)
    T = np.sum(contagens**3 - contagens)
    sigma2 = N * (N + 1) / 12.0 - T / (12.0 * (N - 1))
    linhas = []
    for i in range(len(niveis_local) - 1):
        for j in range(i + 1, len(niveis_local)):
            a, b = niveis_local[i], niveis_local[j]
            ra = ranks[rotulos == a]
            rb = ranks[rotulos == b]
            denom = np.sqrt(sigma2 * (1.0 / len(ra) + 1.0 / len(rb)))
            z = (ra.mean() - rb.mean()) / denom if denom > 0 else np.nan
            p = 2.0 * stats.norm.sf(abs(z)) if np.isfinite(z) else np.nan
            linhas.append({"A": a, "B": b, "comparacao": f"{a} - {b}", "z_dunn": z, "p_dunn_raw": p})
    return pd.DataFrame(linhas)

def a12(a, b):
    a = np.asarray(a, dtype=float)[:, None]
    b = np.asarray(b, dtype=float)[None, :]
    cmp = a - b
    return (np.sum(cmp > 0) + 0.5 * np.sum(cmp == 0)) / cmp.size

def orientar(x, indicador):
    x = np.asarray(x, dtype=float)
    return x if indicador == "hv" else -x

def classificar_a12_teorico(valor):
    if not np.isfinite(valor):
        return None
    d = round(abs(valor - 0.5), 6)
    if d <= 0.06:
        return "Desprezível"
    if d <= 0.14:
        return "Pequena"
    if d <= 0.21:
        return "Média"
    return "Grande"

def classificar_a12_script(valor):
    if not np.isfinite(valor):
        return None
    d = abs(valor - 0.5)
    if d <= 0.06:
        return "Desprezível"
    if d <= 0.14:
        return "Pequena"
    if d <= 0.21:
        return "Média"
    return "Grande"

INDICADORES = ["hv", "igd_plus", "ed_media", "ed_min", "spacing"]

# 1. Descriptive Statistics & Shapiro-Wilk per configuration
desc_rows = []
for ind in INDICADORES:
    ranks_all = stats.rankdata(df[ind].values)
    df[f"rank_{ind}"] = ranks_all
    for idx, cfg_id in enumerate(IDS):
        c_short = f"C{idx+1}"
        sub = df[df["C"] == c_short]
        v = sub[ind].values
        r_mean = sub[f"rank_{ind}"].mean()
        q1, q3 = np.percentile(v, [25, 75])
        sw_w, sw_p = stats.shapiro(v)
        desc_rows.append({
            "sistema": "jpetstore",
            "config": c_short,
            "config_id": cfg_id,
            "indicador": ind,
            "n": len(v),
            "media": v.mean(),
            "mediana": np.median(v),
            "desvio_padrao": v.std(ddof=1),
            "q1": q1,
            "q3": q3,
            "iqr": q3 - q1,
            "minimo": v.min(),
            "maximo": v.max(),
            "posto_medio": r_mean,
            "shapiro_W": sw_w,
            "shapiro_p": sw_p,
            "normal_ok_05": bool(sw_p > 0.05)
        })

df_desc = pd.DataFrame(desc_rows)
df_desc.to_csv(os.path.join(OUT_ARTIFACTS, "estatistica_descritiva_jpetstore.csv"), index=False)

# 2. Global Tests & Assumptions Summary
resumo_rows = []
pares_rows = []

for ind in INDICADORES:
    grupos = [df[df["C"] == c][ind].values for c in niveis_C]
    sw_ps = [stats.shapiro(g).pvalue for g in grupos]
    norm_grupos_ok = bool(all(p > 0.05 for p in sw_ps))
    min_sw_p = min(sw_ps)
    min_sw_cfg = niveis_C[int(np.argmin(sw_ps))]

    # Residuals normality
    res = (df[ind] - df.groupby("C")[ind].transform("mean")).values
    sw_res_w, sw_res_p = stats.shapiro(res)

    # Levene (center='median')
    lev = stats.levene(*grupos, center="median")
    lev_ok = bool(lev.pvalue > 0.05)

    # ANOVA & Kruskal-Wallis
    f_stat, f_p = stats.f_oneway(*grupos)
    kw_stat, kw_p = stats.kruskal(*grupos)

    teste_formal = "ANOVA" if (norm_grupos_ok and lev_ok) else "Kruskal-Wallis"

    # Post-hoc Tukey & Dunn across all 28 pairs
    tuk = stats.tukey_hsd(*grupos)
    dunn_df = dunn_pairwise(df[ind].values, df["C"].values, niveis_C)
    dunn_df["p_dunn_bh"] = bh_fdr(dunn_df["p_dunn_raw"])

    tuk_p_list = []
    tuk_diff_list = []
    for i, j in combinations(range(len(niveis_C)), 2):
        tuk_diff_list.append(tuk.statistic[i, j])
        tuk_p_list.append(tuk.pvalue[i, j])
    dunn_df["diff_media"] = tuk_diff_list
    dunn_df["p_tukey"] = tuk_p_list
    dunn_df["p_tukey_bh"] = bh_fdr(tuk_p_list)

    for idx_row, row in dunn_df.iterrows():
        ca, cb = row["A"], row["B"]
        xa = orientar(df[df["C"] == ca][ind].values, ind)
        xb = orientar(df[df["C"] == cb][ind].values, ind)
        val_a12 = a12(xa, xb)
        if val_a12 > 0.5:
            direcao = f"{ca} melhor que {cb}"
        elif val_a12 < 0.5:
            direcao = f"{cb} melhor que {ca}"
        else:
            direcao = "Equivalentes"
        pares_rows.append({
            "sistema": "jpetstore",
            "indicador": ind,
            "par": f"{ca} x {cb}",
            "config_A": ca,
            "config_B": cb,
            "diff_media": row["diff_media"],
            "p_tukey": row["p_tukey"],
            "p_tukey_bh": row["p_tukey_bh"],
            "z_dunn": row["z_dunn"],
            "p_dunn_raw": row["p_dunn_raw"],
            "p_dunn_bh": row["p_dunn_bh"],
            "sig_dunn_bh_05": bool(row["p_dunn_bh"] <= 0.05),
            "A12": val_a12,
            "direcao": direcao,
            "magnitude_teorica": classificar_a12_teorico(val_a12),
            "magnitude_script": classificar_a12_script(val_a12)
        })

    n_sig_dunn_bh = int((dunn_df["p_dunn_bh"] <= 0.05).sum())
    n_sig_tukey = int((np.array(tuk_p_list) <= 0.05).sum())

    resumo_rows.append({
        "sistema": "jpetstore",
        "indicador": ind,
        "normalidade_8_grupos_ok": norm_grupos_ok,
        "menor_shapiro_p_grupo": min_sw_p,
        "config_menor_shapiro": min_sw_cfg,
        "shapiro_residuos_W": sw_res_w,
        "shapiro_residuos_p": sw_res_p,
        "levene_W": lev.statistic,
        "levene_p": lev.pvalue,
        "levene_ok": lev_ok,
        "teste_formal_pressupostos": teste_formal,
        "anova_F": f_stat,
        "anova_p": f_p,
        "kruskal_H": kw_stat,
        "kruskal_p": kw_p,
        "pares_sig_dunn_bh": n_sig_dunn_bh,
        "pares_sig_tukey": n_sig_tukey
    })

df_resumo = pd.DataFrame(resumo_rows)
df_resumo.to_csv(os.path.join(OUT_ARTIFACTS, "testes_resumo_jpetstore.csv"), index=False)

df_pares = pd.DataFrame(pares_rows)
df_pares.to_csv(os.path.join(OUT_ARTIFACTS, "testes_pares_posthoc_bh_a12_jpetstore.csv"), index=False)

# 3. Factorial Analysis (F1: Algoritmo, F2: Elitismo, F3: Restrição)
parts = df["config"].str.split("__", expand=True)
df["algoritmo"] = parts[0].map({"nsgaiii": "NSGA-III", "rnsgaiii": "R-NSGA-III"})
df["elitismo"] = parts[1].map({"elit_on": "ativo", "elit_off": "inativo"})
df["restricao"] = parts[2].map({"penalty": "PENALTY", "kill": "KILL"})

fatores_spec = [
    ("restricao", "PENALTY", "KILL"),
    ("algoritmo", "NSGA-III", "R-NSGA-III"),
    ("elitismo", "ativo", "inativo")
]

fat_rows = []
for ind in INDICADORES:
    for fat_col, niv_a, niv_b in fatores_spec:
        va = df[df[fat_col] == niv_a][ind].values
        vb = df[df[fat_col] == niv_b][ind].values
        xa = orientar(va, ind)
        xb = orientar(vb, ind)
        val_a12 = a12(xa, xb)
        u_stat, u_p = stats.mannwhitneyu(va, vb, alternative="two-sided")
        fat_rows.append({
            "sistema": "jpetstore",
            "indicador": ind,
            "fator": fat_col,
            "nivel_A": niv_a,
            "nivel_B": niv_b,
            "n_A": len(va),
            "n_B": len(vb),
            "media_A": va.mean(),
            "mediana_A": np.median(va),
            "dp_A": va.std(ddof=1),
            "media_B": vb.mean(),
            "mediana_B": np.median(vb),
            "dp_B": vb.std(ddof=1),
            "mannwhitney_U": u_stat,
            "mannwhitney_p": u_p,
            "A12_A_vs_B": val_a12,
            "magnitude_teorica": classificar_a12_teorico(val_a12),
            "magnitude_script": classificar_a12_script(val_a12)
        })

df_fat = pd.DataFrame(fat_rows)
df_fat.to_csv(os.path.join(OUT_ARTIFACTS, "testes_fatores_a12_jpetstore.csv"), index=False)

print("\n=== TESTES RESUMO JPETSTORE ===")
print(df_resumo.to_string(index=False))

print("\n=== ESTATISTICA DESCRITIVA JPETSTORE (HV, IGD+, ED_MEDIA) ===")
print(df_desc[df_desc["indicador"].isin(["hv", "igd_plus", "ed_media"])][["config", "indicador", "media", "mediana", "desvio_padrao", "iqr", "minimo", "maximo", "posto_medio", "shapiro_W", "shapiro_p"]].to_string(index=False))

print("\n=== FATORES PRINCIPAIS JPETSTORE ===")
print(df_fat[df_fat["indicador"].isin(["hv", "igd_plus", "ed_media", "ed_min", "spacing"])][["indicador", "fator", "nivel_A", "nivel_B", "mediana_A", "mediana_B", "mannwhitney_p", "A12_A_vs_B", "magnitude_teorica"]].to_string(index=False))
