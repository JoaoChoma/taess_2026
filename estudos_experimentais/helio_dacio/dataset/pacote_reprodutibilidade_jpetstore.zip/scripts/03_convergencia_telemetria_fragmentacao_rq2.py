import glob
import itertools
import json
import os
import zipfile
from collections import Counter, defaultdict

import numpy as np
import pandas as pd
from scipy import stats

OUT_DIR = "/working_dir/c_437f55c4f6d2d292/artifacts/file_generation/ttl=63d/output"
os.makedirs(OUT_DIR, exist_ok=True)

CONFIG_MAP = {
    1: ("C1", "nsgaiii__elit_on__penalty", "NSGA-III", "ativo", "PENALTY"),
    2: ("C2", "nsgaiii__elit_off__penalty", "NSGA-III", "inativo", "PENALTY"),
    3: ("C3", "rnsgaiii__elit_on__penalty", "R-NSGA-III", "ativo", "PENALTY"),
    4: ("C4", "rnsgaiii__elit_off__penalty", "R-NSGA-III", "inativo", "PENALTY"),
    5: ("C5", "nsgaiii__elit_on__kill", "NSGA-III", "ativo", "KILL"),
    6: ("C6", "nsgaiii__elit_off__kill", "NSGA-III", "inativo", "KILL"),
    7: ("C7", "rnsgaiii__elit_on__kill", "R-NSGA-III", "ativo", "KILL"),
    8: ("C8", "rnsgaiii__elit_off__kill", "R-NSGA-III", "inativo", "KILL"),
}

OBJETIVOS = ["Coupling", "Cohesion", "Overhead", "Functionality", "ReusePerMS"]
PENALTY_THRESHOLD = 1e5

DOMAIN_MAP = {
    "Account": "account",
    "AccountActionBean": "account",
    "AccountService": "account",
    "Category": "catalog",
    "Product": "catalog",
    "Item": "catalog",
    "CatalogActionBean": "catalog",
    "CatalogService": "catalog",
    "Cart": "cart",
    "CartItem": "cart",
    "CartActionBean": "cart",
    "Order": "order",
    "LineItem": "order",
    "Sequence": "order",
    "OrderActionBean": "order",
    "OrderService": "order",
    "AbstractActionBean": "order",
}
DOMAINS = ["account", "catalog", "cart", "order"]


def get_best_and_mean_metrics(cands_entry):
    m = np.array(
        [
            [mt["value"] for mt in sorted(c["metrics"], key=lambda x: x["index"])]
            for c in cands_entry["candidates"]
        ],
        dtype=float,
    )
    viable_mask = (m < PENALTY_THRESHOLD).all(axis=1)
    m_viable = m[viable_mask]
    n_viable = int(viable_mask.sum())
    n_infeasible = int((~viable_mask).sum())
    bmin = dict(zip(OBJETIVOS, m_viable.min(axis=0)))
    bmed = dict(zip(OBJETIVOS, np.median(m_viable, axis=0)))
    bmean = dict(zip(OBJETIVOS, m_viable.mean(axis=0)))
    return bmin, bmed, bmean, n_viable, n_infeasible


def analyze_microservices(microservices):
    dom_idx = {d: i for i, d in enumerate(DOMAINS)}
    mat = np.zeros((4, 4), dtype=int)
    mat_222 = np.zeros((4, 4), dtype=int)
    cls_ms = defaultdict(lambda: [0, 0, 0, 0])
    ms_methods = defaultdict(lambda: defaultdict(set))
    total_dom = 0
    total_dom_222 = 0

    for m_i, ms in enumerate(microservices):
        for c in ms["components"]:
            cname = c["name"]
            if cname.startswith("_star_t_"):
                continue
            parts = cname.split(".")
            cls = parts[-2]
            mname = parts[-1]
            dom = DOMAIN_MAP.get(cls)
            if dom is not None:
                mat[m_i, dom_idx[dom]] += 1
                total_dom += 1
                if cls != "AbstractActionBean":
                    mat_222[m_i, dom_idx[dom]] += 1
                    total_dom_222 += 1
            cls_ms[cls][m_i] += 1
            ms_methods[cls][mname].add(m_i)

    best_perm = max(
        itertools.permutations(range(4)),
        key=lambda p: sum(mat[m_i, p[m_i]] for m_i in range(4)),
    )
    best_match = sum(mat[m_i, best_perm[m_i]] for m_i in range(4))
    adh_pct = 100.0 * best_match / total_dom if total_dom else 0.0

    best_match_222 = max(
        sum(mat_222[m_i, p[m_i]] for m_i in range(4))
        for p in itertools.permutations(range(4))
    )
    adh_222_pct = 100.0 * best_match_222 / total_dom_222 if total_dom_222 else 0.0

    dom_adh = {}
    for m_i in range(4):
        d_i = best_perm[m_i]
        d_name = DOMAINS[d_i]
        d_tot = mat[:, d_i].sum()
        dom_adh[d_name] = 100.0 * mat[m_i, d_i] / d_tot if d_tot > 0 else 0.0

    total_m = sum(sum(v) for v in cls_ms.values())
    maj_m = sum(max(v) for v in cls_ms.values())
    cls_purity = 100.0 * maj_m / total_m if total_m else 0.0
    n_classes = len(cls_ms)
    n_intact = sum(1 for v in cls_ms.values() if sum(1 for x in v if x > 0) == 1)
    n_split = sum(1 for v in cls_ms.values() if sum(1 for x in v if x > 0) > 1)
    n_split_3plus = sum(1 for v in cls_ms.values() if sum(1 for x in v if x > 0) >= 3)
    n_split_4 = sum(1 for v in cls_ms.values() if sum(1 for x in v if x > 0) == 4)
    mean_ms_per_cls = float(
        np.mean([sum(1 for x in v if x > 0) for v in cls_ms.values()])
    )

    gs_total = 0
    gs_split = 0
    for cls, mdict in ms_methods.items():
        for mname in list(mdict.keys()):
            if mname.startswith("get") and len(mname) > 3:
                prop = mname[3:]
                sname = "set" + prop
                if sname in mdict:
                    gs_total += 1
                    if mdict[mname] != mdict[sname]:
                        gs_split += 1
            elif mname.startswith("is") and len(mname) > 2:
                prop = mname[2:]
                sname = "set" + prop
                if sname in mdict:
                    gs_total += 1
                    if mdict[mname] != mdict[sname]:
                        gs_split += 1

    lam_total = 0
    lam_split = 0
    for cls, mdict in ms_methods.items():
        for mname in list(mdict.keys()):
            if mname.startswith("lambda$"):
                enc = mname.split("$")[1]
                if enc in mdict:
                    lam_total += 1
                    if mdict[mname] != mdict[enc]:
                        lam_split += 1

    return {
        "adh_pct": adh_pct,
        "adh_222_pct": adh_222_pct,
        "adh_account_pct": dom_adh["account"],
        "adh_catalog_pct": dom_adh["catalog"],
        "adh_cart_pct": dom_adh["cart"],
        "adh_order_pct": dom_adh["order"],
        "cls_purity_pct": cls_purity,
        "n_classes": n_classes,
        "n_intact_cls": n_intact,
        "n_split_cls": n_split,
        "pct_split_cls": 100.0 * n_split / n_classes,
        "n_split_3plus_ms": n_split_3plus,
        "n_split_4ms": n_split_4,
        "mean_ms_per_cls": mean_ms_per_cls,
        "gs_total": gs_total,
        "gs_split": gs_split,
        "gs_split_pct": 100.0 * gs_split / gs_total if gs_total else 0.0,
        "lam_total": lam_total,
        "lam_split": lam_split,
        "lam_split_pct": 100.0 * lam_split / lam_total if lam_total else 0.0,
    }


def main():
    zips = sorted(glob.glob("downloads/study_pg20261017585*.zip"))
    gen0_path = "work_jpetstore/taess_2026-912eb74cb8fa1839a49fac7f84d8c080f3cede8e/estudos_experimentais/helio_dacio/dataset/jpetclinic/jpetstore_numMS4.json"
    gen0_data = json.load(open(gen0_path, encoding="utf-8"))
    g0_min, g0_med, g0_mean, g0_n_viable, g0_n_inf = get_best_and_mean_metrics(gen0_data[0])

    # Build global component ID -> name map and alphabetical Gen 0 synthetic microservices
    id2name = {}
    with zipfile.ZipFile(zips[0], "r") as z:
        bs0 = json.loads(z.read("bestSolutions.json").decode("utf-8"))
        for entry in bs0:
            for sol in entry["solutions"]:
                for ms in sol["microservices"]:
                    for c in ms["components"]:
                        id2name[c["id"]] = c["name"]

    all_sorted_names = sorted(list(set(id2name.values())))
    gen0_ms = []
    chunk_size = len(all_sorted_names) / 4.0
    for i in range(4):
        lo = int(round(i * chunk_size))
        hi = int(round((i + 1) * chunk_size))
        gen0_ms.append(
            {"id": f"microservice{i}", "components": [{"name": n} for n in all_sorted_names[lo:hi]]}
        )
    gen0_arch = analyze_microservices(gen0_ms)

    conv_exec_rows = []
    telemetry_rows = []
    frag_rows = []

    for zpath in zips:
        with zipfile.ZipFile(zpath, "r") as z:
            manifest = json.loads(z.read("manifest.json").decode("utf-8"))
            cfg_num = int(zpath.split("__config_")[1].split("__")[0])
            rep = int(manifest["study"]["repetition"])
            cfg_code, cfg_id, alg, elit, rest = CONFIG_MAP[cfg_num]

            cands = json.loads(z.read("candidates.json").decode("utf-8"))
            bs = json.loads(z.read("bestSolutions.json").decode("utf-8"))
            inter = json.loads(z.read("interactions.json").decode("utf-8"))
            dec = json.loads(z.read("decisions.json").decode("utf-8"))
            idiff = json.loads(z.read("intent_diffusion.json").decode("utf-8"))
            be = json.loads(z.read("behavioral_events.json").decode("utf-8"))

            for entry in bs:
                for sol in entry["solutions"]:
                    for ms in sol["microservices"]:
                        for c in ms["components"]:
                            id2name[c["id"]] = c["name"]

            # 1. Convergence rows (Gen 0 + Gen 600, 820, 950, 999)
            conv_exec_rows.append(
                {
                    "config_code": cfg_code,
                    "config_id": cfg_id,
                    "algoritmo": alg,
                    "elitismo": elit,
                    "restricao": rest,
                    "repeticao": rep,
                    "geracao": 0,
                    "n_viaveis": g0_n_viable,
                    "n_inviaveis_penalizados": g0_n_inf,
                    "n_dm_flag": 0,
                    "first_cand_dm_flag": False,
                    **{f"{k}_min": g0_min[k] for k in OBJETIVOS},
                    **{f"{k}_mediana_pop": g0_med[k] for k in OBJETIVOS},
                    **{f"{k}_media_pop": g0_mean[k] for k in OBJETIVOS},
                }
            )

            dm_by_gen = {}
            first_dm_by_gen = {}
            for entry in cands:
                g = int(entry["generation"])
                bmin, bmed, bmean, n_v, n_inf = get_best_and_mean_metrics(entry)
                n_dm = sum(1 for c in entry["candidates"] if c.get("hasDmInteraction"))
                f_dm = bool(entry["candidates"][0].get("hasDmInteraction"))
                dm_by_gen[g] = n_dm
                first_dm_by_gen[g] = f_dm
                conv_exec_rows.append(
                    {
                        "config_code": cfg_code,
                        "config_id": cfg_id,
                        "algoritmo": alg,
                        "elitismo": elit,
                        "restricao": rest,
                        "repeticao": rep,
                        "geracao": g,
                        "n_viaveis": n_v,
                        "n_inviaveis_penalizados": n_inf,
                        "n_dm_flag": n_dm,
                        "first_cand_dm_flag": f_dm,
                        **{f"{k}_min": bmin[k] for k in OBJETIVOS},
                        **{f"{k}_mediana_pop": bmed[k] for k in OBJETIVOS},
                        **{f"{k}_media_pop": bmean[k] for k in OBJETIVOS},
                    }
                )

            # 2. Telemetry rows per checkpoint (600, 820, 950)
            for g in [600, 820, 950]:
                it_g = [x for x in inter if x["generation"] == g][0]
                dec_g = [x for x in dec if x["generation"] == g][0]
                be_g = [x for x in be if x.get("generation") == g]

                ops = it_g.get("modificationStack", [])
                n_ops_modstack = len(ops)
                mod_move_ops = sum(1 for op in ops if op["operation"]["type"] == "MOVE_COMPONENT")
                mod_other_ops = [
                    op["operation"]["type"]
                    for op in ops
                    if op["operation"]["type"] != "MOVE_COMPONENT"
                ]
                mod_moved_ids = set()
                for op in ops:
                    if op["operation"]["type"] == "MOVE_COMPONENT":
                        mod_moved_ids.update(
                            op["operation"]["parameters"].get("toDestinationList", [])
                        )
                        mod_moved_ids.update(
                            op["operation"]["parameters"].get("toSourceList", [])
                        )

                n_be_applied = sum(1 for e in be_g if e["type"] == "operation_applied")
                n_be_undone = sum(1 for e in be_g if e["type"] == "operation_undone")
                n_be_redone = sum(1 for e in be_g if e["type"] == "operation_redone")

                # Reconstruct exact move batches from intent_diffusion.json
                co_g = [
                    x
                    for x in idiff["intents"]
                    if x["originGeneration"] == g
                    and x["type"] == "CO_LOCATE"
                    and x["source"] == "STRUCTURAL"
                ]
                sep_g = [
                    x
                    for x in idiff["intents"]
                    if x["originGeneration"] == g
                    and x["type"] == "SEPARATE"
                    and x["source"] == "STRUCTURAL"
                ]
                by_from = defaultdict(list)
                for x in sep_g:
                    by_from[tuple(x["relation"]["fromIds"])].append(
                        x["relation"]["componentId"]
                    )
                batches = [
                    ftuple
                    for ftuple, clist in by_from.items()
                    if len(ftuple) <= len(clist)
                ]
                recovered_ids = set(cid for b in batches for cid in b)
                n_batches = len(batches)
                n_methods_moved = sum(len(b) for b in batches)

                moved_names = [id2name.get(cid, cid) for cid in recovered_ids]
                moved_classes = [n.split(".")[-2] if "." in n else n for n in moved_names]
                moved_domains = [DOMAIN_MAP.get(c, "other") for c in moved_classes]
                top_dom = Counter(moved_domains).most_common(1)[0][0] if moved_domains else ""
                dom_homog = (
                    Counter(moved_domains).most_common(1)[0][1] / len(moved_domains)
                    if moved_domains
                    else 0.0
                )
                top_cls = Counter(moved_classes).most_common(1)[0][0] if moved_classes else ""
                cls_homog = (
                    Counter(moved_classes).most_common(1)[0][1] / len(moved_classes)
                    if moved_classes
                    else 0.0
                )

                # Intent diffusion metrics at origin generation (g) and final generation (999)
                co_strict_init = float(np.mean([x["series"][0][2] for x in co_g])) if co_g else 0.0
                co_strict_999 = float(np.mean([x["series"][-1][2] for x in co_g])) if co_g else 0.0
                co_partial_init = float(np.mean([x["series"][0][3] for x in co_g])) if co_g else 0.0
                co_partial_999 = float(np.mean([x["series"][-1][3] for x in co_g])) if co_g else 0.0
                co_carriers_999 = float(np.mean([x["series"][-1][1] for x in co_g])) if co_g else 0.0

                sep_strict_999 = float(np.mean([x["series"][-1][2] for x in sep_g])) if sep_g else 0.0
                sep_partial_999 = float(np.mean([x["series"][-1][3] for x in sep_g])) if sep_g else 0.0

                next_g = 820 if g == 600 else (950 if g == 820 else 999)

                telemetry_rows.append(
                    {
                        "config_code": cfg_code,
                        "config_id": cfg_id,
                        "algoritmo": alg,
                        "elitismo": elit,
                        "restricao": rest,
                        "repeticao": rep,
                        "geracao_pausa": g,
                        "index_solution_escolhido": int(dec_g["indexSolution"]),
                        "escolheu_primeiro_candidato": int(dec_g["indexSolution"]) == 0,
                        "propagation_enabled": bool(dec_g["propagationEnabled"]),
                        "cluster_id": it_g["clusterId"],
                        "n_target_cluster": len(it_g["targetSolutionIndices"]),
                        "modstack_exportado": n_ops_modstack > 0,
                        "n_ops_modstack": n_ops_modstack,
                        "n_move_ops_modstack": mod_move_ops,
                        "outras_ops_modstack": "|".join(mod_other_ops),
                        "n_metodos_modstack": len(mod_moved_ids),
                        "be_applied": n_be_applied,
                        "be_undone": n_be_undone,
                        "be_redone": n_be_redone,
                        "n_lotes_intent": n_batches,
                        "n_metodos_movidos_real": n_methods_moved,
                        "dentro_faixa_5_a_9": 5 <= n_methods_moved <= 9,
                        "dominio_predominante_lote": top_dom,
                        "homogeneidade_dominio_lote": round(dom_homog, 4),
                        "classe_predominante_lote": top_cls,
                        "homogeneidade_classe_lote": round(cls_homog, 4),
                        "n_intents_colocate": len(co_g),
                        "n_intents_separate": len(sep_g),
                        "colocate_strict_frac_inicio": round(co_strict_init, 4),
                        "colocate_strict_frac_999": round(co_strict_999, 4),
                        "colocate_partial_sat_inicio": round(co_partial_init, 4),
                        "colocate_partial_sat_999": round(co_partial_999, 4),
                        "colocate_carriers_999": round(co_carriers_999, 2),
                        "separate_strict_frac_999": round(sep_strict_999, 4),
                        "separate_partial_sat_999": round(sep_partial_999, 4),
                        "pop_dm_flag_prox_pausa": dm_by_gen[next_g],
                        "pop_dm_flag_999": dm_by_gen[999],
                        "first_cand_dm_flag_999": first_dm_by_gen[999],
                    }
                )

            # 3. Architectural Fragmentation & Domain Adherence rows across Gen 0, 600, 820, 950, 999
            frag_rows.append(
                {
                    "config_code": cfg_code,
                    "config_id": cfg_id,
                    "algoritmo": alg,
                    "elitismo": elit,
                    "restricao": rest,
                    "repeticao": rep,
                    "geracao": 0,
                    "criterio_selecao": "Pop_Inicial_Deterministica",
                    "metric_focus": "All_Identical",
                    "Coupling": g0_min["Coupling"],
                    "Cohesion": g0_min["Cohesion"],
                    "Overhead": g0_min["Overhead"],
                    "Functionality": g0_min["Functionality"],
                    "ReusePerMS": g0_min["ReusePerMS"],
                    **gen0_arch,
                }
            )

            for entry in bs:
                g = int(entry["generation"])
                sols = entry["solutions"]
                analyzed = []
                for s_i, sol in enumerate(sols):
                    arch = analyze_microservices(sol["microservices"])
                    mvals = {m["name"]: m["value"] for m in sol["metrics"]}
                    analyzed.append((s_i, sol["metric"], mvals, arch))

                # Record (A) Best-Adherence Extreme Solution (as in Table V / Fig 4 of main.tex)
                best_adh_item = max(analyzed, key=lambda x: (x[3]["adh_pct"], x[3]["cls_purity_pct"]))
                frag_rows.append(
                    {
                        "config_code": cfg_code,
                        "config_id": cfg_id,
                        "algoritmo": alg,
                        "elitismo": elit,
                        "restricao": rest,
                        "repeticao": rep,
                        "geracao": g,
                        "criterio_selecao": "Maior_Aderencia_Extremos",
                        "metric_focus": best_adh_item[1],
                        **best_adh_item[2],
                        **best_adh_item[3],
                    }
                )

                # Record (B) Sol0 (Cohesion - First Solution Displayed to DM)
                sol0_item = analyzed[0]
                frag_rows.append(
                    {
                        "config_code": cfg_code,
                        "config_id": cfg_id,
                        "algoritmo": alg,
                        "elitismo": elit,
                        "restricao": rest,
                        "repeticao": rep,
                        "geracao": g,
                        "criterio_selecao": "Primeira_Exibida_Cohesion",
                        "metric_focus": sol0_item[1],
                        **sol0_item[2],
                        **sol0_item[3],
                    }
                )

                # Record (C) Best Class-Purity Extreme Solution
                best_cp_item = max(analyzed, key=lambda x: (x[3]["cls_purity_pct"], x[3]["adh_pct"]))
                frag_rows.append(
                    {
                        "config_code": cfg_code,
                        "config_id": cfg_id,
                        "algoritmo": alg,
                        "elitismo": elit,
                        "restricao": rest,
                        "repeticao": rep,
                        "geracao": g,
                        "criterio_selecao": "Maior_Pureza_Classe_Extremos",
                        "metric_focus": best_cp_item[1],
                        **best_cp_item[2],
                        **best_cp_item[3],
                    }
                )

    df_conv = pd.DataFrame(conv_exec_rows).sort_values(["config_code", "repeticao", "geracao"])
    df_tel = pd.DataFrame(telemetry_rows).sort_values(["config_code", "repeticao", "geracao_pausa"])
    df_frag = pd.DataFrame(frag_rows).sort_values(
        ["criterio_selecao", "config_code", "repeticao", "geracao"]
    )

    conv_csv = os.path.join(OUT_DIR, "evolucao_fitness_geracoes_jpetstore.csv")
    tel_csv = os.path.join(OUT_DIR, "telemetria_interacoes_rq2_jpetstore.csv")
    frag_csv = os.path.join(OUT_DIR, "fragmentacao_arquitetural_rq2_jpetstore.csv")

    df_conv.to_csv(conv_csv, index=False)
    df_tel.to_csv(tel_csv, index=False)
    df_frag.to_csv(frag_csv, index=False)

    print("Saved CSVs:")
    print(" ", conv_csv, len(df_conv))
    print(" ", tel_csv, len(df_tel))
    print(" ", frag_csv, len(df_frag))

    # Print statistical tests on RQ2 metrics at Gen 999
    sub_adh999 = df_frag[
        (df_frag["criterio_selecao"] == "Maior_Aderencia_Extremos") & (df_frag["geracao"] == 999)
    ]
    for col in ["adh_pct", "cls_purity_pct", "n_split_cls", "gs_split_pct"]:
        groups = [
            sub_adh999[sub_adh999["config_code"] == f"C{i}"][col].to_numpy()
            for i in range(1, 9)
        ]
        kw_stat, kw_p = stats.kruskal(*groups)
        pen = sub_adh999[sub_adh999["restricao"] == "PENALTY"][col].to_numpy()
        kill = sub_adh999[sub_adh999["restricao"] == "KILL"][col].to_numpy()
        mw_u, mw_p = stats.mannwhitneyu(pen, kill, alternative="two-sided")
        print(
            f"Gen 999 [{col}] KW H={kw_stat:.4f} (p={kw_p:.4f}) | PEN mean={pen.mean():.2f} (med={np.median(pen):.2f}) vs KILL mean={kill.mean():.2f} (med={np.median(kill):.2f}), MW p={mw_p:.4f}"
        )


if __name__ == "__main__":
    main()
