import os
import re
import sys
import glob
import json
import zipfile
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

PASTA_ZIPS = sys.argv[1] if len(sys.argv) > 1 else "persona_2"
PASTA_SAIDA = sys.argv[2] if len(sys.argv) > 2 else "fig4"
PERSONA = "P2"

ROTULOS = {
    "Coupling": "Acoplamento",
    "Cohesion": "Coesão (1/x)",
    "Overhead": "Overhead de rede",
    "Functionality": "Funcionalidade (1/x)",
    "ReusePerMS": "Reúso por MS (1/x)",
}

CONFIG_ORDEM = [
    "nsgaiii__elit_on__penalty",
    "nsgaiii__elit_off__penalty",
    "rnsgaiii__elit_on__penalty",
    "rnsgaiii__elit_off__penalty",
    "nsgaiii__elit_on__kill",
    "nsgaiii__elit_off__kill",
    "rnsgaiii__elit_on__kill",
    "rnsgaiii__elit_off__kill",
]
CONFIG_N = {f"config_{i + 1}": c for i, c in enumerate(CONFIG_ORDEM)}

CORES_EXEC = ["#d62728", "#1f77b4", "#f2c40f", "#000000", "#e67e22"]


def titulo_config(cfg):
    alg, elit, cons = cfg.split("__")
    alg = "R-NSGA-III" if alg == "rnsgaiii" else "NSGA-III"
    elit = "elit. ON" if elit == "elit_on" else "elit. OFF"
    return f"{alg} | {elit} | {cons.upper()}"


def fmt(x):
    if abs(x) >= 1000:
        return f"{x:.0f}"
    if abs(x) >= 10:
        return f"{x:.1f}"
    return f"{x:.3f}"


def coords_paralelas(ax, blocos, nomes, lim_min, lim_max, titulo="", alpha=0.6, lw=0.8, n_ticks=5,
                     fs_tick=7, fs_eixo=7.5, fs_titulo=10):
    k = len(nomes)
    x = np.arange(k)
    amp = np.where(lim_max - lim_min == 0, 1.0, lim_max - lim_min)

    for dados, cor in blocos:
        norm = (dados - lim_min) / amp
        norm[:, (lim_max - lim_min) == 0] = 0.5
        for linha in norm:
            ax.plot(x, linha, color=cor, alpha=alpha, lw=lw)

    for j in range(k):
        ax.axvline(j, color="black", lw=1.2, zorder=5)
        if lim_max[j] == lim_min[j]:
            pos, vals = [0.5], [lim_min[j]]
        else:
            pos = np.linspace(0, 1, n_ticks)
            vals = lim_min[j] + pos * amp[j]
        for p, v in zip(pos, vals):
            ax.plot([j - 0.04, j], [p, p], color="black", lw=1, zorder=6)
            ax.text(j - 0.06, p, fmt(v), ha="right", va="center", fontsize=fs_tick, zorder=7,
                    bbox=dict(facecolor="white", edgecolor="none", alpha=0.7, pad=0.5))

    ax.set_xticks(x)
    ax.set_xticklabels([ROTULOS.get(n, n) for n in nomes], fontsize=fs_eixo,
                       rotation=15, ha="right", rotation_mode="anchor")
    ax.set_xlim(-0.35, k - 1 + 0.15)
    ax.set_ylim(-0.04, 1.04)
    ax.set_yticks([])
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)
    ax.set_title(titulo, fontsize=fs_titulo)


def ler_zip(caminho):
    with zipfile.ZipFile(caminho) as zf:
        arqs = {os.path.basename(n): n for n in zf.namelist()}
        fr = json.loads(zf.read(arqs["frontiers.json"]))
        man = json.loads(zf.read(arqs["manifest.json"])) if "manifest.json" in arqs else {}

    nomes = fr["metricNames"]
    study, run = man.get("study", {}), man.get("run", {})
    cfg, rep, sist = study.get("configId"), study.get("repetition"), run.get("sourceId")

    m = re.search(r"config_(\d+)__(.+?)__execution_(\d+)", os.path.basename(caminho))
    if m:
        cfg = cfg or CONFIG_N.get(f"config_{m.group(1)}")
        sist = sist or m.group(2)
        rep = rep or int(m.group(3))

    pontos = np.unique(np.array(fr["frontier"], dtype=float), axis=0)
    return dict(config=cfg, repeticao=int(rep), sistema=sist, nomes=nomes, pontos=pontos)


def carregar_zips(pasta):
    zips = sorted(glob.glob(os.path.join(pasta, "**", "study_*.zip"), recursive=True))
    execs = [ler_zip(z) for z in zips]
    print(f"{len(execs)} execuções lidas")
    return execs


def limites(execs):
    todos = np.vstack([e["pontos"] for e in execs])
    return todos.min(axis=0), todos.max(axis=0)


def blocos_config(execs, cfg):
    sel = sorted([e for e in execs if e["config"] == cfg], key=lambda e: e["repeticao"])
    blocos = [(e["pontos"], CORES_EXEC[(e["repeticao"] - 1) % len(CORES_EXEC)]) for e in sel]
    return sel, blocos


def fig4_por_config(execs, sistema, pasta):
    execs = [e for e in execs if e["sistema"] == sistema]
    nomes = execs[0]["nomes"]
    lmin, lmax = limites(execs)

    for i, cfg in enumerate(CONFIG_ORDEM, 1):
        sel, blocos = blocos_config(execs, cfg)
        if not sel:
            continue
        leg = [Line2D([0], [0], color=CORES_EXEC[(e["repeticao"] - 1) % len(CORES_EXEC)], lw=2,
                      label=f"Execução {e['repeticao']} ({len(e['pontos'])} sol.)") for e in sel]
        fig, ax = plt.subplots(figsize=(8, 5))
        coords_paralelas(ax, blocos, nomes, lmin, lmax,
                         titulo=f"Config. {i} · {titulo_config(cfg)} — {sistema}")
        ax.legend(handles=leg, loc="upper center", bbox_to_anchor=(0.5, -0.1),
                  ncol=3, frameon=False, fontsize=8)
        fig.tight_layout()
        fig.savefig(os.path.join(pasta, f"{sistema}_fig4_config_{i}.png"), dpi=300, bbox_inches="tight")
        plt.close(fig)


def fig4_8_paineis(execs, sistema, pasta):
    execs = [e for e in execs if e["sistema"] == sistema]
    nomes = execs[0]["nomes"]
    lmin, lmax = limites(execs)

    fig, axs = plt.subplots(2, 4, figsize=(20.8, 8.6))
    axs = axs.ravel()
    for i, cfg in enumerate(CONFIG_ORDEM):
        _, blocos = blocos_config(execs, cfg)
        coords_paralelas(axs[i], blocos, nomes, lmin, lmax,
                         titulo=f"({chr(ord('a') + i)}) Config. {i + 1} · {titulo_config(cfg)}")

    reps = sorted({e["repeticao"] for e in execs})
    leg = [Line2D([0], [0], color=CORES_EXEC[(r - 1) % len(CORES_EXEC)], lw=2,
                  label=f"Execução {r}") for r in reps]
    fig.legend(handles=leg, loc="lower center", ncol=len(leg), frameon=False,
               bbox_to_anchor=(0.5, -0.01))
    fig.suptitle(f"{sistema} — fronteiras finais nos 5 objetivos "
                 f"(eixos normalizados no sistema; em todos, mais baixo é melhor)",
                 fontsize=13)
    fig.tight_layout(rect=(0, 0.03, 1, 0.97))
    fig.savefig(os.path.join(pasta, f"{sistema}_fig4_8_paineis.png"), dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig4_4_paineis(execs, sistema, pasta):
    """Duas figuras por sistema (penalty e kill), 2x2, com fontes maiores."""
    execs = [e for e in execs if e["sistema"] == sistema]
    nomes = execs[0]["nomes"]
    lmin, lmax = limites(execs)

    grupos = {"penalty": CONFIG_ORDEM[:4], "kill": CONFIG_ORDEM[4:]}
    for nome_grupo, cfgs in grupos.items():
        fig, axs = plt.subplots(2, 2, figsize=(13.0, 9.0))
        axs = axs.ravel()
        desloc = 0 if nome_grupo == "penalty" else 4
        for i, cfg in enumerate(cfgs):
            _, blocos = blocos_config(execs, cfg)
            coords_paralelas(axs[i], blocos, nomes, lmin, lmax,
                             titulo=f"Config. {desloc + i + 1} · {titulo_config(cfg)}",
                             lw=0.9, n_ticks=5,
                             fs_tick=9, fs_eixo=10.5, fs_titulo=13)
        reps = sorted({e["repeticao"] for e in execs})
        leg = [Line2D([0], [0], color=CORES_EXEC[(r - 1) % len(CORES_EXEC)], lw=2.5,
                      label=f"Execução {r}") for r in reps]
        fig.legend(handles=leg, loc="lower center", ncol=len(leg), frameon=False,
                   fontsize=11, bbox_to_anchor=(0.5, -0.005))
        fig.suptitle(f"{sistema} — fronteiras finais, estratégia {nome_grupo.upper()} "
                     f"(eixos normalizados no sistema; em todos, mais baixo é melhor)",
                     fontsize=14)
        fig.tight_layout(rect=(0, 0.04, 1, 0.96))
        fig.savefig(os.path.join(pasta, f"{sistema}_fig4_{nome_grupo}.png"),
                    dpi=300, bbox_inches="tight")
        fig.savefig(os.path.join(pasta, f"{sistema}_fig4_{nome_grupo}.pdf"),
                    bbox_inches="tight")
        plt.close(fig)


if __name__ == "__main__":
    os.makedirs(PASTA_SAIDA, exist_ok=True)
    execs = carregar_zips(PASTA_ZIPS)
    for sistema in sorted({e["sistema"] for e in execs}):
        fig4_por_config(execs, sistema, PASTA_SAIDA)
        fig4_8_paineis(execs, sistema, PASTA_SAIDA)
        fig4_4_paineis(execs, sistema, PASTA_SAIDA)
    print(f"Gráficos salvos em {PASTA_SAIDA}/")
