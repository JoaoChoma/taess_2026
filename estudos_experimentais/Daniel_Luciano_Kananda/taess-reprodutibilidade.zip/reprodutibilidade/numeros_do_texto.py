"""Reproduz as tabelas e os números do artigo que NÃO saem do pipeline.py.

Lê só os 80 zips de dados/persona_2/ e escreve em saida/numeros_do_texto/:

  sistemas.csv          -> Tabela I (características dos sistemas-alvo)
  ordem_execucao.csv    -> Seção 3.2 (ordem real, participante, início/fim, tempo)
  ambiente.csv          -> Seção 3.2 (Java, SO, versão do backend registrados)
  tempos.csv            -> Seção 3.2 (média e mediana do tempo decorrido)
  arquitetural.csv      -> Tabela IV (qualidade arquitetural e faixa de tamanho)
  interacao.csv         -> Tabela V  (conformidade da interação da persona)
  cardinalidade.csv     -> Seção 4.2 (pontos distintos não dominados, duplicatas)
  reuso.csv             -> Seções 4.0a/4.1 (variação do objetivo de reúso)
  penalty_kill.csv      -> Seção 4.0a (medianas penalty x kill sobre as fronteiras)
  escolhas.csv          -> Seção 4.4/RQ2 (índices escolhidos nas 240 pausas)
  descritiva_indicadores.csv -> tabelas descritivas da Seção 4.3 (média, mediana, DP, mín, máx)
  shapiro_levene.csv    -> Shapiro-Wilk por grupo e Levene por indicador (texto e apêndice)
  tabelas/arquitetural.tex, tabelas/interacao.tex

Uso:  .venv/bin/python numeros_do_texto.py
"""
from __future__ import annotations

import datetime as dt
import json
import re
import statistics as st
import zipfile
from collections import Counter
from pathlib import Path

import pandas as pd

RAIZ = Path(__file__).resolve().parent
DADOS = RAIZ / "dados" / "persona_2"
SAIDA = RAIZ / "saida" / "numeros_do_texto"
NO_SINTETICO = "_star_t_._star_t_"
FUSO = dt.timezone(dt.timedelta(hours=-3))  # horário de Brasília
SISTEMAS = ["spring-petclinic", "jpetstore"]
NOME_TEX = {"spring-petclinic": r"\textit{spring-petclinic}", "jpetstore": r"\textit{jPetStore}"}


def le(z: zipfile.ZipFile, nome: str):
    return json.load(z.open(nome))


def zips():
    for caminho in sorted(DADOS.glob("config_*/*/*.zip")):
        z = zipfile.ZipFile(caminho)
        m = le(z, "manifest.json")
        yield z, m, int(m["study"]["configLabel"].split("_")[1]), m["run"]["sourceId"], m["study"]["repetition"]


def tamanhos(sol: dict) -> list[int]:
    # tamanho de cada microsserviço em elementos do grafo, como a ferramenta conta
    return [len(ms["components"]) for ms in sol["microservices"]]


def nao_dominados(pontos: list[tuple]) -> list[tuple]:
    unicos = list(dict.fromkeys(pontos))
    nd = []
    for p in unicos:
        dominado = any(all(q[i] <= p[i] for i in range(len(p))) and q != p for q in unicos)
        if not dominado:
            nd.append(p)
    return nd


def sistemas(execs) -> pd.DataFrame:
    linhas = []
    for sistema in SISTEMAS:
        z = next(e[0] for e in execs if e[3] == sistema)
        sol = le(z, "bestSolutions.json")[-1]["solutions"][0]
        comps = [c for ms in sol["microservices"] for c in ms["components"] if c["name"] != NO_SINTETICO]
        nomes = [c["name"] for c in comps]
        classes = {n.rsplit(".", 1)[0] for n in nomes}
        pacotes = {c.rsplit(".", 1)[0] for c in classes}
        deps = sum(1 for c in comps for d in c["dependencies"] if d["targetComponent"] != NO_SINTETICO)
        funcs = {f for c in comps for f in c["functionalities"]}
        multi = sum(1 for c in comps if len(set(c["functionalities"])) > 1)
        linhas.append(dict(sistema=sistema, pacotes=len(pacotes), classes=len(classes), metodos=len(nomes),
                           dependencias=deps, funcionalidades=len(funcs), metodos_multi_func=multi,
                           elementos_grafo=len(nomes) + 1, funcionalidades_nomes=";".join(sorted(funcs))))
    return pd.DataFrame(linhas)


def ordem(execs) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    linhas = []
    for z, m, cfg, sistema, rep in execs:
        t = le(z, "timing.json")
        fim = dt.datetime.fromisoformat(m["generatedAt"][:19]).replace(tzinfo=dt.timezone.utc)
        parede = t["wallTimeMs"] / 1000
        inicio = fim - dt.timedelta(seconds=parede)
        linhas.append(dict(inicio=inicio.astimezone(FUSO), fim=fim.astimezone(FUSO), config=cfg, sistema=sistema,
                           repeticao=rep, participante=m["study"]["participantCode"], tempo_s=round(parede, 1),
                           java=m["app"]["javaVersion"], so=m["app"]["os"], backend=m["app"]["backendVersion"],
                           seed=m["run"]["seed"]))
    df = pd.DataFrame(linhas).sort_values("inicio").reset_index(drop=True)
    # participantes anonimizados na ordem em que começaram (A, B, C)
    rot = {p: chr(65 + i) for i, p in enumerate(dict.fromkeys(df["participante"]))}
    df["participante"] = df["participante"].map(rot)
    df.insert(0, "ordem", range(1, len(df) + 1))
    amb = df.groupby(["java", "so", "backend"], dropna=False).size().reset_index(name="execucoes")
    tempos = df.groupby("sistema")["tempo_s"].agg(["count", "mean", "median", "sum"]).reset_index()
    tempos.loc[len(tempos)] = ["total", len(df), df.tempo_s.mean(), df.tempo_s.median(), df.tempo_s.sum()]
    tempos["horas"] = tempos["sum"] / 3600
    df["inicio"] = df["inicio"].dt.strftime("%Y-%m-%d %H:%M")
    df["fim"] = df["fim"].dt.strftime("%Y-%m-%d %H:%M")
    return df, amb, tempos


def arquitetural(execs, n_elem: dict) -> pd.DataFrame:
    fr, arq = {}, {}
    for z, m, cfg, sistema, rep in execs:
        f = le(z, "frontiers.json")
        fr.setdefault((sistema, cfg), []).extend(f["frontier"])
        cfgm = m["config"]
        lo, hi = cfgm["minRatio"] * n_elem[sistema], cfgm["maxRatio"] * n_elem[sistema]
        for sol in le(z, "bestSolutions.json")[-1]["solutions"]:  # geração 999, 5 soluções
            tam = tamanhos(sol)
            arq.setdefault((sistema, cfg), []).append((max(tam), min(tam), any(t < lo or t > hi for t in tam), lo, hi))
    linhas = []
    for (sistema, cfg), pts in sorted(fr.items(), key=lambda k: (SISTEMAS.index(k[0][0]), k[0][1])):
        a = arq[(sistema, cfg)]
        linhas.append(dict(sistema=sistema, config=cfg,
                           acoplamento=st.median(p[0] for p in pts), overhead=st.median(p[2] for p in pts),
                           coesao=st.median(p[1] for p in pts), funcionalidade=st.median(p[3] for p in pts),
                           reuso=st.median(p[4] for p in pts), maior_ms=st.median(x[0] for x in a),
                           menor_ms=st.median(x[1] for x in a), arquiteturas=len(a),
                           fora_da_faixa_pct=100 * sum(x[2] for x in a) / len(a),
                           faixa_min=a[0][3], faixa_max=a[0][4]))
    return pd.DataFrame(linhas)


def penalty_kill(execs) -> pd.DataFrame:
    """Medianas sobre todas as soluções finais, penalty (1-4) x kill (5-8): Seção 4.0a."""
    pts = {}
    for z, m, cfg, sistema, rep in execs:
        pts.setdefault((sistema, "penalty" if cfg <= 4 else "kill"), []).extend(le(z, "frontiers.json")["frontier"])
    return pd.DataFrame([dict(sistema=s, restricao=r, solucoes=len(v), acoplamento=st.median(p[0] for p in v),
                              overhead=st.median(p[2] for p in v)) for (s, r), v in pts.items()])


ROTULO = {"nsgaiii__elit_on__penalty": 1, "nsgaiii__elit_off__penalty": 2, "rnsgaiii__elit_on__penalty": 3,
          "rnsgaiii__elit_off__penalty": 4, "nsgaiii__elit_on__kill": 5, "nsgaiii__elit_off__kill": 6,
          "rnsgaiii__elit_on__kill": 7, "rnsgaiii__elit_off__kill": 8}
INDICADORES = ["hv", "igd_plus", "ed_media", "ed_min"]


def descritiva_e_normalidade() -> tuple[pd.DataFrame, pd.DataFrame]:
    """Tabelas descritivas da Seção 4.3 e Shapiro-Wilk/Levene (texto e apêndice).

    Lê os indicadores calculados pelos professores (dados/persona_2/analise/*.csv).
    Levene usa o padrão do SciPy (centro na mediana, isto é, Brown-Forsythe)."""
    from scipy import stats
    desc, norm = [], []
    for sistema in SISTEMAS:
        df = pd.read_csv(DADOS / "analise" / f"P2-Systematic-Decoupler_{sistema}.csv")
        df["c"] = df["config"].map(ROTULO)
        for ind in INDICADORES:
            grupos = [g[ind].to_numpy() for _, g in df.sort_values("c").groupby("c")]
            lev = stats.levene(*grupos).pvalue
            for c, g in df.sort_values("c").groupby("c"):
                v = g[ind]
                desc.append(dict(sistema=sistema, indicador=ind, config=c, n=len(v), media=v.mean(),
                                 mediana=v.median(), dp=v.std(ddof=1), minimo=v.min(), maximo=v.max()))
                sw = stats.shapiro(v)
                norm.append(dict(sistema=sistema, indicador=ind, config=c, shapiro_w=sw.statistic,
                                 shapiro_p=sw.pvalue, levene_p_do_indicador=lev))
    return pd.DataFrame(desc), pd.DataFrame(norm)


def interacao(execs) -> pd.DataFrame:
    cont = {}
    for z, m, cfg, sistema, rep in execs:
        c = cont.setdefault((sistema, cfg), Counter())
        for it in le(z, "interactions.json"):
            c["pausas"] += 1
            pilha = it["modificationStack"]
            if not pilha:
                c["sem_edicao"] += 1
            for op in pilha:
                c[op["operation"]["type"]] += 1
    linhas = [dict(sistema=s, config=k, pausas=c["pausas"], sem_edicao=c["sem_edicao"],
                   mover=c["MOVE_COMPONENT"], dividir=c["SPLIT_MICROSERVICE"],
                   unir=c["MERGE_MICROSERVICES"] + c["MERGE_MICROSERVICE"], congelar=c["FREEZE_MICROSERVICE"],
                   outras=sum(v for t, v in c.items() if t not in {"pausas", "sem_edicao", "MOVE_COMPONENT",
                              "SPLIT_MICROSERVICE", "MERGE_MICROSERVICES", "MERGE_MICROSERVICE", "FREEZE_MICROSERVICE"}))
              for (s, k), c in sorted(cont.items(), key=lambda k: (SISTEMAS.index(k[0][0]), k[0][1]))]
    return pd.DataFrame(linhas)


def escolhas(execs) -> dict:
    idx, primeiro, total = set(), 0, 0
    for z, m, cfg, sistema, rep in execs:
        for d in le(z, "decisions.json"):
            total += 1
            idx.add(d["indexSolution"])
            primeiro += d["indexSolution"] == 0
    return dict(pausas=total, indices_distintos=len(idx), primeiro_da_lista=primeiro)


def cardinalidade(execs) -> pd.DataFrame:
    linhas = []
    for z, m, cfg, sistema, rep in execs:
        pts = [tuple(p) for p in le(z, "frontiers.json")["frontier"]]
        nd = nao_dominados(pts)
        linhas.append(dict(sistema=sistema, config=cfg, repeticao=rep, populacao=len(pts),
                           distintos_nao_dominados=len(nd), duplicatas=len(pts) - len(set(pts))))
    return pd.DataFrame(linhas)


def reuso(execs) -> pd.DataFrame:
    linhas = []
    for sistema in SISTEMAS:
        valores, execucoes, configs = Counter(), set(), set()
        for z, m, cfg, s, rep in execs:
            if s != sistema:
                continue
            for p in le(z, "frontiers.json")["frontier"]:
                valores[round(p[4], 4)] += 1
                if round(p[4], 4) != 1.0:
                    execucoes.add((cfg, rep)); configs.add(cfg)
        total = sum(valores.values())
        linhas.append(dict(sistema=sistema, solucoes=total, diferentes_de_1=total - valores[1.0],
                           pct=100 * (total - valores[1.0]) / total, valores=dict(valores),
                           execucoes_com_variacao=len(execucoes), configs=sorted(configs)))
    return pd.DataFrame(linhas)


def num(v, casas=0):
    return f"{v:.{casas}f}".replace(".", ",")


def tex_arquitetural(df: pd.DataFrame) -> str:
    out = []
    for s in SISTEMAS:
        d = df[df.sistema == s]
        out.append(rf"\multicolumn{{6}}{{l}}{{{NOME_TEX[s]} (faixa: {num(d.faixa_min.iloc[0],1)} a {num(d.faixa_max.iloc[0],1)} métodos)}} \\")
        for r in d.itertuples():
            out.append(f"{r.config} & {num(r.acoplamento)} & {num(r.overhead)} & {num(r.coesao,2)} & "
                       f"{num(r.maior_ms)} & {num(r.fora_da_faixa_pct)}\\% \\\\")
        out.append(r"\midrule")
    return "\n".join(out[:-1]) + "\n"


def tex_interacao(df: pd.DataFrame) -> str:
    out = []
    for s in SISTEMAS:
        out.append(rf"\multicolumn{{5}}{{l}}{{{NOME_TEX[s]}}} \\")
        for r in df[df.sistema == s].itertuples():
            out.append(f"{r.config} & {r.pausas} & {r.sem_edicao} & {r.mover} & {r.dividir} \\\\")
        out.append(r"\midrule")
    return "\n".join(out[:-1]) + "\n"


def main() -> None:
    (SAIDA / "tabelas").mkdir(parents=True, exist_ok=True)
    execs = list(zips())
    assert len(execs) == 80, len(execs)

    sis = sistemas(execs)
    n_elem = dict(zip(sis.sistema, sis.elementos_grafo))
    ordem_df, amb, tempos = ordem(execs)
    arq = arquitetural(execs, n_elem)
    inter = interacao(execs)
    card = cardinalidade(execs)
    reu = reuso(execs)
    pk = penalty_kill(execs)
    desc, norm = descritiva_e_normalidade()
    desc.round(4).to_csv(SAIDA / "descritiva_indicadores.csv", index=False)
    norm.round(4).to_csv(SAIDA / "shapiro_levene.csv", index=False)
    pk.to_csv(SAIDA / "penalty_kill.csv", index=False)
    pd.DataFrame([escolhas(execs)]).to_csv(SAIDA / "escolhas.csv", index=False)

    sis.to_csv(SAIDA / "sistemas.csv", index=False)
    ordem_df.to_csv(SAIDA / "ordem_execucao.csv", index=False)
    amb.to_csv(SAIDA / "ambiente.csv", index=False)
    tempos.to_csv(SAIDA / "tempos.csv", index=False)
    arq.to_csv(SAIDA / "arquitetural.csv", index=False)
    inter.to_csv(SAIDA / "interacao.csv", index=False)
    card.to_csv(SAIDA / "cardinalidade.csv", index=False)
    reu.to_csv(SAIDA / "reuso.csv", index=False)
    (SAIDA / "tabelas" / "arquitetural.tex").write_text(tex_arquitetural(arq), encoding="utf-8")
    (SAIDA / "tabelas" / "interacao.tex").write_text(tex_interacao(inter), encoding="utf-8")

    pd.set_option("display.width", 200)
    print(sis.drop(columns="funcionalidades_nomes"), "\n")
    print(amb, "\n")
    print(tempos, "\n")
    print(ordem_df.groupby(["participante", "config", "sistema"], sort=False)
          .agg(inicio=("inicio", "first"), fim=("fim", "last")), "\n")
    print(arq.round(3), "\n")
    print(inter, "\n", inter[["pausas", "sem_edicao", "mover", "dividir", "unir", "congelar", "outras"]].sum().to_dict())
    print(escolhas(execs), "\n")
    print("cardinalidade:", card.distintos_nao_dominados.min(), "a", card.distintos_nao_dominados.max(), "\n",
          card.groupby(["sistema", "config"]).agg(nd_min=("distintos_nao_dominados", "min"),
                                                   nd_max=("distintos_nao_dominados", "max"),
                                                   dup_min=("duplicatas", "min"), dup_max=("duplicatas", "max")), "\n")
    print(reu.to_string(), "\n")
    print(pk)


if __name__ == "__main__":
    main()
