#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pipeline de dados do artigo TAES II — persona P2-Systematic-Decoupler.

Lê, de uma vez só:
  * os indicadores por execução já calculados pelos professores
    (dados/persona_2/analise/P2-Systematic-Decoupler_<sistema>.csv);
  * os 80 zips das execuções (8 configurações x 2 sistemas x 5 repetições),
    de onde saem tempo, decisões da persona, fitness por geração e a
    fronteira final.

E escreve, em saida/, tudo o que o artigo precisa: tabelas (CSV e LaTeX),
testes estatísticos e figuras. Todo mundo escreve em cima dos mesmos números.

Uso:
    .venv/bin/python pipeline.py

Convenções que valem para o artigo inteiro
------------------------------------------
* Os cinco objetivos são MINIMIZADOS. Coesão, Funcionalidade e Reúso já vêm
  invertidos (1/valor) da ferramenta, então "menor é melhor" nos cinco.
* HV: maior é melhor. IGD+, ED e spacing: menor é melhor.
* Os indicadores foram normalizados por (persona x sistema) pelos professores,
  com ponto de referência 1,1 no espaço normalizado. Por isso só se comparam
  valores DENTRO de um mesmo sistema, nunca entre sistemas.
* As 8 configurações são o cruzamento de três fatores:
      algoritmo   NSGA-III | R-NSGA-III
      elitismo    ligado   | desligado
      restrição   penalty  | kill
"""

from __future__ import annotations

import json
import zipfile
from dataclasses import dataclass
from itertools import combinations
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

RAIZ = Path(__file__).resolve().parent
DADOS = RAIZ / "dados" / "persona_2"
SAIDA = RAIZ / "saida"
PERSONA = "P2-Systematic-Decoupler"

SISTEMAS = ["spring-petclinic", "jpetstore"]
OBJETIVOS = ["Coupling", "Cohesion", "Overhead", "Functionality", "ReusePerMS"]
OBJETIVOS_PT = {
    "Coupling": "Acoplamento",
    "Cohesion": "Coesão (1/x)",
    "Overhead": "Overhead",
    "Functionality": "Funcionalidade (1/x)",
    "ReusePerMS": "Reúso por MS (1/x)",
}

# Indicador -> (rótulo, maior é melhor?)
INDICADORES = {
    "hv": ("HV", True),
    "igd_plus": ("IGD+", False),
    "ed_media": ("ED média", False),
    "ed_min": ("ED mínima", False),
}

# config_N do enunciado -> configId do pacote de dados
CONFIGS = {
    "config_1": "nsgaiii__elit_on__penalty",
    "config_2": "nsgaiii__elit_off__penalty",
    "config_3": "rnsgaiii__elit_on__penalty",
    "config_4": "rnsgaiii__elit_off__penalty",
    "config_5": "nsgaiii__elit_on__kill",
    "config_6": "nsgaiii__elit_off__kill",
    "config_7": "rnsgaiii__elit_on__kill",
    "config_8": "rnsgaiii__elit_off__kill",
}
ROTULO = {v: k.replace("config_", "") for k, v in CONFIGS.items()}
ORDEM_CONFIG = [CONFIGS[f"config_{i}"] for i in range(1, 9)]

ALFA = 0.05


# ----------------------------------------------------------------------------
# 1. Indicadores por execução (fonte: pacote dos professores)
# ----------------------------------------------------------------------------


def fatores(config_id: str) -> dict:
    algoritmo, elitismo, restricao = config_id.split("__")
    return {
        "algoritmo": "R-NSGA-III" if algoritmo == "rnsgaiii" else "NSGA-III",
        "elitismo": "ligado" if elitismo == "elit_on" else "desligado",
        "restricao": "kill" if restricao == "kill" else "penalty",
    }


def carrega_indicadores() -> pd.DataFrame:
    partes = []

    for sistema in SISTEMAS:
        caminho = DADOS / "analise" / f"{PERSONA}_{sistema}.csv"
        df = pd.read_csv(caminho)
        df = df.rename(columns={"config": "config_id"})
        df["sistema"] = sistema
        partes.append(df)

    df = pd.concat(partes, ignore_index=True)

    for coluna, valores in pd.DataFrame(
        [fatores(c) for c in df.config_id]
    ).items():
        df[coluna] = valores.values

    df["config"] = df.config_id.map(ROTULO)
    df["config_id"] = pd.Categorical(df.config_id, ORDEM_CONFIG, ordered=True)

    esperado = len(SISTEMAS) * len(ORDEM_CONFIG) * 5
    if len(df) != esperado:
        raise SystemExit(f"esperava {esperado} execuções, li {len(df)}")
    if not df.completo.all():
        raise SystemExit("há execução incompleta no pacote de indicadores")

    return df.sort_values(["sistema", "config_id", "repeticao"]).reset_index(drop=True)


# ----------------------------------------------------------------------------
# 2. Os zips: tempo, decisões, fitness por geração, fronteira final
# ----------------------------------------------------------------------------


@dataclass
class Execucao:
    config_id: str
    sistema: str
    repeticao: int
    participante: str
    num_ms: int
    geracoes: int
    tempo_s: float
    geracoes_por_min: float
    decisoes: list
    evolucao: pd.DataFrame
    fronteira: pd.DataFrame


def _valores(candidato: dict) -> dict:
    return {m["name"]: float(m["value"]) for m in candidato["metrics"]}


def le_zip(caminho: Path) -> Execucao:
    with zipfile.ZipFile(caminho) as z:
        def js(nome):
            with z.open(nome) as f:
                return json.load(f)

        manifest = js("manifest.json")
        timing = js("timing.json")
        decisoes = js("decisions.json")
        candidatos = js("candidates.json")
        fronteira = js("frontiers.json")

    estudo, run = manifest["study"], manifest["run"]

    # Fitness por geração: uma linha por (geração, objetivo), com o melhor
    # (mínimo) e a média dos 132 indivíduos daquela geração.
    linhas = []
    for entrada in candidatos:
        geracao = entrada["generation"]
        valores = pd.DataFrame([_valores(c) for c in entrada["candidates"]])

        for objetivo in OBJETIVOS:
            linhas.append(
                {
                    "geracao": geracao,
                    "objetivo": objetivo,
                    "melhor": valores[objetivo].min(),
                    "media": valores[objetivo].mean(),
                }
            )

    evolucao = pd.DataFrame(linhas)

    frente = pd.DataFrame(fronteira["frontier"], columns=fronteira["metricNames"])
    frente["geracao"] = fronteira["generation"]

    return Execucao(
        config_id=estudo["configId"],
        sistema=run["sourceId"],
        repeticao=int(estudo["repetition"]),
        participante=str(estudo["participantCode"]),
        num_ms=int(run["numberOfMicroservices"]),
        geracoes=int(timing.get("generations", run.get("generations", 0))),
        tempo_s=float(timing.get("wallTimeMs", 0)) / 1000.0,
        geracoes_por_min=float(timing.get("generationsPerMinute", float("nan"))),
        decisoes=decisoes,
        evolucao=evolucao,
        fronteira=frente,
    )


def le_todos_os_zips() -> list[Execucao]:
    zips = sorted(DADOS.glob("config_*/*/*.zip"))
    if not zips:
        raise SystemExit(f"nenhum zip de execução em {DADOS}")

    execucoes = [le_zip(z) for z in zips]
    print(f"  {len(execucoes)} execuções lidas dos zips")
    return execucoes


def fitness_gen0() -> pd.DataFrame:
    """A geração 0 é determinística: um único vetor de fitness por sistema."""
    linhas = []

    for arquivo in sorted((DADOS / "analise" / "gen0").glob("*.json")):
        sistema, num_ms = arquivo.stem.rsplit("_numMS", 1)
        entrada = json.load(arquivo.open())[0]
        valores = pd.DataFrame([_valores(c) for c in entrada["candidates"]])

        for objetivo in OBJETIVOS:
            linhas.append(
                {
                    "sistema": sistema,
                    "num_ms": int(num_ms),
                    "geracao": 0,
                    "objetivo": objetivo,
                    "melhor": valores[objetivo].min(),
                    "media": valores[objetivo].mean(),
                }
            )

    return pd.DataFrame(linhas)


# ----------------------------------------------------------------------------
# 3. Estatística
# ----------------------------------------------------------------------------


def a12(a: np.ndarray, b: np.ndarray, maior_melhor: bool) -> float:
    """Vargha-Delaney Â12: P(uma execução de A ser melhor que uma de B).

    Empates contam meio. O sinal do indicador entra aqui, para que Â12 > 0,5
    signifique sempre "A é melhor", qualquer que seja o indicador.
    """
    if not maior_melhor:
        a, b = -np.asarray(a, float), -np.asarray(b, float)

    a, b = np.asarray(a, float), np.asarray(b, float)
    comparacoes = (a[:, None] > b[None, :]).sum() + 0.5 * (a[:, None] == b[None, :]).sum()
    return float(comparacoes / (a.size * b.size))


def magnitude(valor: float) -> str:
    """Escala de Vargha-Delaney para |Â12 - 0,5|."""
    d = abs(valor - 0.5)
    if d < 0.06:
        return "desprezível"
    if d < 0.14:
        return "pequeno"
    if d < 0.21:
        return "médio"
    return "grande"


def holm(ps: list[float]) -> list[float]:
    """Correção de Holm-Bonferroni, preservando a ordem de entrada."""
    n = len(ps)
    ordem = np.argsort(ps)
    ajustados = np.empty(n, float)
    maior = 0.0

    for posicao, indice in enumerate(ordem):
        valor = (n - posicao) * ps[indice]
        maior = max(maior, min(valor, 1.0))
        ajustados[indice] = maior

    return ajustados.tolist()


def bh(ps: list[float]) -> list[float]:
    """Benjamini-Hochberg (FDR), que é o que o pacote dos professores pede."""
    ps_arr = np.asarray(ps, float)
    n = ps_arr.size
    ordem = np.argsort(ps_arr)
    ajustados = np.empty(n)
    menor = 1.0

    for posicao in range(n - 1, -1, -1):
        indice = ordem[posicao]
        menor = min(menor, ps_arr[indice] * n / (posicao + 1))
        ajustados[indice] = menor

    return ajustados.tolist()


def dunn(grupos: list[np.ndarray]) -> list[tuple[int, int, float, float]]:
    """Pós-hoc de Dunn: usa o posto de TODAS as observações juntas, e não só
    as do par, que é o que lhe dá poder onde o Wilcoxon 5x5 não tem."""
    todos = np.concatenate(grupos)
    n_total = todos.size
    postos = stats.rankdata(todos)

    fatias, inicio = [], 0
    for g in grupos:
        fatias.append(postos[inicio : inicio + g.size])
        inicio += g.size

    _, contagens = np.unique(todos, return_counts=True)
    empates = (contagens**3 - contagens).sum()
    sigma2 = n_total * (n_total + 1) / 12 - empates / (12 * (n_total - 1))

    saida = []
    for i, j in combinations(range(len(grupos)), 2):
        erro = np.sqrt(sigma2 * (1 / grupos[i].size + 1 / grupos[j].size))
        z = (fatias[i].mean() - fatias[j].mean()) / erro
        saida.append((i, j, z, 2 * (1 - stats.norm.cdf(abs(z)))))

    return saida


def dunn_por_indicador(df: pd.DataFrame) -> pd.DataFrame:
    """Dunn + BH por (sistema x indicador), com Â12 orientado ao lado."""
    linhas = []

    for sistema in SISTEMAS:
        for coluna, (rotulo, maior_melhor) in INDICADORES.items():
            base = df[df.sistema == sistema]
            grupos = [
                base[base.config_id == c][coluna].to_numpy() for c in ORDEM_CONFIG
            ]
            resultados = dunn(grupos)
            ajustados = bh([r[3] for r in resultados])

            for (i, j, z, p), p_bh in zip(resultados, ajustados):
                a, b = ORDEM_CONFIG[i], ORDEM_CONFIG[j]
                efeito = a12(grupos[i], grupos[j], maior_melhor)

                linhas.append(
                    {
                        "sistema": sistema,
                        "indicador": rotulo,
                        "a": ROTULO[a],
                        "b": ROTULO[b],
                        "z": z,
                        "p": p,
                        "p_bh": p_bh,
                        "a12": efeito,
                        "magnitude": magnitude(efeito),
                        "melhor": ROTULO[a] if efeito > 0.5 else ROTULO[b],
                        "significativo": p_bh < ALFA,
                    }
                )

    return pd.DataFrame(linhas)


def kruskal_por_indicador(df: pd.DataFrame) -> pd.DataFrame:
    """Kruskal-Wallis entre as 8 configurações, por sistema e indicador."""
    linhas = []

    for sistema in SISTEMAS:
        for coluna, (rotulo, _) in INDICADORES.items():
            grupos = [
                df[(df.sistema == sistema) & (df.config_id == c)][coluna].to_numpy()
                for c in ORDEM_CONFIG
            ]
            h, p = stats.kruskal(*grupos)
            k, n = len(grupos), sum(len(g) for g in grupos)

            linhas.append(
                {
                    "sistema": sistema,
                    "indicador": rotulo,
                    "H": h,
                    "gl": k - 1,
                    "p": p,
                    # eta² baseado em H (Tomczak & Tomczak)
                    "eta2": (h - k + 1) / (n - k),
                    "significativo": p < ALFA,
                }
            )

    return pd.DataFrame(linhas)


def pares_por_indicador(df: pd.DataFrame) -> pd.DataFrame:
    """Wilcoxon rank-sum (Mann-Whitney U) par a par, com Holm dentro de cada
    (sistema x indicador), mais o tamanho de efeito Â12."""
    linhas = []

    for sistema in SISTEMAS:
        for coluna, (rotulo, maior_melhor) in INDICADORES.items():
            bloco, ps = [], []

            for a, b in combinations(ORDEM_CONFIG, 2):
                xa = df[(df.sistema == sistema) & (df.config_id == a)][coluna].to_numpy()
                xb = df[(df.sistema == sistema) & (df.config_id == b)][coluna].to_numpy()
                u, p = stats.mannwhitneyu(xa, xb, alternative="two-sided")
                efeito = a12(xa, xb, maior_melhor)

                bloco.append(
                    {
                        "sistema": sistema,
                        "indicador": rotulo,
                        "a": ROTULO[a],
                        "b": ROTULO[b],
                        "mediana_a": float(np.median(xa)),
                        "mediana_b": float(np.median(xb)),
                        "U": u,
                        "p": p,
                        "a12": efeito,
                        "magnitude": magnitude(efeito),
                    }
                )
                ps.append(p)

            for linha, ajustado in zip(bloco, holm(ps)):
                linha["p_holm"] = ajustado
                linha["significativo"] = ajustado < ALFA

            linhas.extend(bloco)

    return pd.DataFrame(linhas)


def fatores_por_indicador(df: pd.DataFrame) -> pd.DataFrame:
    """Cada fator isolado (20 execuções contra 20), que é onde há poder
    estatístico: a comparação par a par entre configurações tem 5 contra 5."""
    niveis = {
        "algoritmo": ("NSGA-III", "R-NSGA-III"),
        "elitismo": ("ligado", "desligado"),
        "restricao": ("penalty", "kill"),
    }
    linhas = []

    for sistema in SISTEMAS:
        for coluna, (rotulo, maior_melhor) in INDICADORES.items():
            bloco, ps = [], []

            for fator, (nivel_a, nivel_b) in niveis.items():
                base = df[df.sistema == sistema]
                xa = base[base[fator] == nivel_a][coluna].to_numpy()
                xb = base[base[fator] == nivel_b][coluna].to_numpy()
                u, p = stats.mannwhitneyu(xa, xb, alternative="two-sided")
                efeito = a12(xa, xb, maior_melhor)

                bloco.append(
                    {
                        "sistema": sistema,
                        "indicador": rotulo,
                        "fator": fator,
                        "nivel_a": nivel_a,
                        "nivel_b": nivel_b,
                        "n_a": xa.size,
                        "n_b": xb.size,
                        "mediana_a": float(np.median(xa)),
                        "mediana_b": float(np.median(xb)),
                        "U": u,
                        "p": p,
                        "a12": efeito,
                        "magnitude": magnitude(efeito),
                    }
                )
                ps.append(p)

            for linha, ajustado in zip(bloco, holm(ps)):
                linha["p_holm"] = ajustado
                linha["significativo"] = ajustado < ALFA

            linhas.extend(bloco)

    return pd.DataFrame(linhas)


def resumo_por_config(df: pd.DataFrame) -> pd.DataFrame:
    colunas = list(INDICADORES) + ["tempo_s"]
    # O merge com os metadados dos zips desfaz o Categorical, e a ordem viraria
    # alfabética (C6, C2, C5...). A tabela do artigo tem de sair em C1..C8.
    df = df.assign(config_id=pd.Categorical(df.config_id, ORDEM_CONFIG, ordered=True))
    agregado = (
        df.groupby(["sistema", "config_id"], observed=True)[colunas]
        .agg(["mean", "std", "median", "min", "max"])
        .reset_index()
    )
    agregado.columns = [
        c[0] if not c[1] else f"{c[0]}_{c[1]}" for c in agregado.columns
    ]
    agregado.insert(2, "config", agregado.config_id.map(ROTULO))
    return agregado.sort_values(["sistema", "config_id"], key=lambda c: c)


def ranking(df: pd.DataFrame) -> pd.DataFrame:
    """Posto médio de cada configuração dentro de cada sistema, por indicador,
    e o posto médio geral — a leitura direta da RQ1."""
    linhas = []

    for sistema in SISTEMAS:
        base = df[df.sistema == sistema]
        postos = {}

        for coluna, (rotulo, maior_melhor) in INDICADORES.items():
            medianas = base.groupby("config_id", observed=True)[coluna].median()
            postos[rotulo] = medianas.rank(ascending=not maior_melhor)

        tabela = pd.DataFrame(postos)
        tabela["posto_medio"] = tabela.mean(axis=1)
        tabela = tabela.reset_index()
        tabela.insert(0, "sistema", sistema)
        tabela.insert(2, "config", tabela.config_id.map(ROTULO))
        linhas.append(tabela.sort_values("posto_medio"))

    return pd.concat(linhas, ignore_index=True)


# ----------------------------------------------------------------------------
# 4. Tabelas em LaTeX
# ----------------------------------------------------------------------------


def num(valor: float, casas: int = 3) -> str:
    """Número com vírgula decimal, como manda o texto em português."""
    return f"{valor:.{casas}f}".replace(".", ",")


def valor_p(p: float) -> str:
    return "$<$0,001" if p < 0.001 else num(p, 3)


def tex_resumo(resumo: pd.DataFrame, sistema: str) -> str:
    base = resumo[resumo.sistema == sistema]
    linhas = [
        r"\begin{table}[t]",
        r"\caption{Indicadores por configuração --- " + sistema +
        r" (média $\pm$ desvio padrão, 5 execuções).}",
        r"\label{tab:indicadores-" + sistema + "}",
        r"\centering",
        # O IEEEtran já põe a tabela em \footnotesize, então mudar a fonte não
        # resolve: o que faz caber é apertar o espaço entre colunas.
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{lcccc}",
        r"\toprule",
        r"Config. & HV $\uparrow$ & IGD+ $\downarrow$ & ED média $\downarrow$ & Tempo (s) \\",
        r"\midrule",
    ]

    for _, r in base.iterrows():
        linhas.append(
            f"{r.config} & {num(r.hv_mean)} $\\pm$ {num(r.hv_std)} "
            f"& {num(r.igd_plus_mean)} $\\pm$ {num(r.igd_plus_std)} "
            f"& {num(r.ed_media_mean)} $\\pm$ {num(r.ed_media_std)} "
            f"& {r.tempo_s_mean:.0f} \\\\"
        )

    linhas += [r"\bottomrule", r"\end{tabular}", r"\end{table}", ""]
    return "\n".join(linhas)


def tex_kruskal(kw: pd.DataFrame) -> str:
    linhas = [
        r"\begin{table}[t]",
        r"\caption{Kruskal-Wallis entre as oito configurações ($\alpha = 0{,}05$).}",
        r"\label{tab:kruskal}",
        r"\centering",
        r"\begin{tabular}{llccc}",
        r"\toprule",
        r"Sistema & Indicador & $H$ & $p$ & $\eta^2$ \\",
        r"\midrule",
    ]

    for _, r in kw.iterrows():
        linhas.append(
            f"{r.sistema} & {r.indicador} & {num(r.H, 2)} & {valor_p(r.p)} "
            f"& {num(r.eta2)} \\\\"
        )

    linhas += [r"\bottomrule", r"\end{tabular}", r"\end{table}", ""]
    return "\n".join(linhas)


def tex_dunn(dunn_bh: pd.DataFrame) -> str:
    """Resumo compacto do pós-hoc: quem supera quem, por sistema e indicador."""
    linhas = [
        r"\begin{table}[t]",
        r"\caption{Pós-hoc de Dunn com correção de Benjamini-Hochberg: pares com "
        r"$p_{BH} < 0{,}05$. Lê-se \textit{A} $>$ \textit{B} como ``A superou B''. "
        r"Nenhum par apontou no sentido contrário.}",
        r"\label{tab:dunn}",
        r"\centering",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{llp{4.6cm}}",
        r"\toprule",
        r"Sistema & Indicador & Pares significativos \\",
        r"\midrule",
    ]

    for sistema in SISTEMAS:
        for rotulo, _ in INDICADORES.values():
            bloco = dunn_bh[
                (dunn_bh.sistema == sistema)
                & (dunn_bh.indicador == rotulo)
                & dunn_bh.significativo
            ]

            if bloco.empty:
                texto = "---"
            else:
                perdedores = {}
                for r in bloco.itertuples():
                    vencedor = r.melhor
                    perdedor = r.b if vencedor == r.a else r.a
                    perdedores.setdefault(vencedor, []).append(perdedor)

                texto = "; ".join(
                    f"{v} $>$ {', '.join(sorted(p))}"
                    for v, p in sorted(perdedores.items())
                )

            linhas.append(f"{sistema} & {rotulo} & {texto} \\\\")

        linhas.append(r"\midrule" if sistema == SISTEMAS[0] else "")

    linhas += [r"\bottomrule", r"\end{tabular}", r"\end{table}", ""]
    return "\n".join(l for l in linhas if l)


def tex_fatores(fat: pd.DataFrame) -> str:
    nomes = {"algoritmo": "Algoritmo", "elitismo": "Elitismo", "restricao": "Restrição"}
    linhas = [
        r"\begin{table*}[t]",
        r"\caption{Efeito de cada fator isolado (20 execuções por nível), "
        r"com Wilcoxon rank-sum, $p$ corrigido por Holm e $\hat{A}_{12}$ "
        r"orientado (>0,5 favorece o primeiro nível).}",
        r"\label{tab:fatores}",
        r"\centering",
        r"\footnotesize",
        r"\begin{tabular}{llllcc}",
        r"\toprule",
        r"Sistema & Indicador & Fator & Níveis & $p_{Holm}$ & $\hat{A}_{12}$ \\",
        r"\midrule",
    ]

    for _, r in fat.iterrows():
        p = valor_p(r.p_holm)
        destaque = r"\textbf{" + p + "}" if r.significativo else p
        linhas.append(
            f"{r.sistema} & {r.indicador} & {nomes[r.fator]} "
            f"& {r.nivel_a} vs. {r.nivel_b} & {destaque} "
            f"& {num(r.a12, 2)} ({r.magnitude}) \\\\"
        )

    linhas += [r"\bottomrule", r"\end{tabular}", r"\end{table*}", ""]
    return "\n".join(linhas)


# ----------------------------------------------------------------------------
# 5. Figuras
# ----------------------------------------------------------------------------


def figura_boxplots(df: pd.DataFrame, destino: Path) -> None:
    for sistema in SISTEMAS:
        base = df[df.sistema == sistema]
        fig, eixos = plt.subplots(1, 4, figsize=(13, 3.4))

        for eixo, coluna in zip(eixos, ["hv", "igd_plus", "ed_media", "ed_min"]):
            rotulo, maior_melhor = INDICADORES[coluna]
            dados = [
                base[base.config_id == c][coluna].to_numpy() for c in ORDEM_CONFIG
            ]
            eixo.boxplot(dados, tick_labels=[ROTULO[c] for c in ORDEM_CONFIG])
            seta = "↑" if maior_melhor else "↓"
            eixo.set_title(f"{rotulo} {seta}", fontsize=10)
            eixo.tick_params(axis="x", labelrotation=0, labelsize=8)
            eixo.grid(axis="y", alpha=0.3)

        fig.suptitle(sistema, fontsize=11)
        fig.tight_layout()
        fig.savefig(destino / f"boxplots_{sistema}.pdf")
        fig.savefig(destino / f"boxplots_{sistema}.png", dpi=200)
        plt.close(fig)


def figura_evolucao(evolucao: pd.DataFrame, destino: Path) -> None:
    """Fitness médio da população por geração, um painel por objetivo."""
    for sistema in SISTEMAS:
        base = evolucao[evolucao.sistema == sistema]
        fig, eixos = plt.subplots(1, 5, figsize=(13, 2.8))

        for eixo, objetivo in zip(eixos, OBJETIVOS):
            dados = base[base.objetivo == objetivo]

            for config_id in ORDEM_CONFIG:
                serie = (
                    dados[dados.config_id == config_id]
                    .groupby("geracao")["media"]
                    .mean()
                    .sort_index()
                )
                eixo.plot(serie.index, serie.to_numpy(), marker="o", markersize=3,
                          linewidth=1, label=ROTULO[config_id])

            eixo.set_title(OBJETIVOS_PT[objetivo], fontsize=9)
            eixo.set_xlabel("geração", fontsize=8)
            eixo.tick_params(labelsize=7)
            eixo.grid(alpha=0.3)

        eixos[-1].legend(fontsize=6, ncol=2, loc="best")
        fig.suptitle(f"Evolução do fitness médio — {sistema}", fontsize=11)
        fig.tight_layout()
        fig.savefig(destino / f"evolucao_{sistema}.pdf")
        fig.savefig(destino / f"evolucao_{sistema}.png", dpi=200)
        plt.close(fig)


# ----------------------------------------------------------------------------
# 6. Execução
# ----------------------------------------------------------------------------


def main() -> None:
    for pasta in ["tabelas", "figuras", "testes"]:
        (SAIDA / pasta).mkdir(parents=True, exist_ok=True)

    print("1. indicadores por execução")
    indicadores = carrega_indicadores()

    print("2. zips das execuções")
    execucoes = le_todos_os_zips()

    meta = pd.DataFrame(
        [
            {
                "config_id": e.config_id,
                "sistema": e.sistema,
                "repeticao": e.repeticao,
                "num_ms": e.num_ms,
                "geracoes": e.geracoes,
                "tempo_s": e.tempo_s,
                "geracoes_por_min": e.geracoes_por_min,
                "decisoes": ";".join(
                    f"g{d['generation']}:s{d['indexSolution']}" for d in e.decisoes
                ),
            }
            for e in execucoes
        ]
    )

    df = indicadores.merge(meta, on=["config_id", "sistema", "repeticao"], how="left")
    if df.tempo_s.isna().any():
        faltando = df[df.tempo_s.isna()][["sistema", "config_id", "repeticao"]]
        raise SystemExit(f"execuções sem zip correspondente:\n{faltando}")

    df.to_csv(SAIDA / "execucoes.csv", index=False)

    # Evolução do fitness: gen 0 (determinística) + as 4 gerações exportadas.
    gen0 = fitness_gen0()
    partes = []

    for e in execucoes:
        inicial = gen0[(gen0.sistema == e.sistema) & (gen0.num_ms == e.num_ms)]
        bloco = pd.concat([inicial.drop(columns=["sistema", "num_ms"]), e.evolucao])
        bloco = bloco.assign(
            config_id=e.config_id, config=ROTULO[e.config_id],
            sistema=e.sistema, repeticao=e.repeticao,
        )
        partes.append(bloco)

    evolucao = pd.concat(partes, ignore_index=True)
    evolucao.to_csv(SAIDA / "evolucao_fitness.csv", index=False)

    # Fronteira final de cada execução, para as coordenadas paralelas.
    frentes = pd.concat(
        [
            e.fronteira.assign(
                config_id=e.config_id, config=ROTULO[e.config_id],
                sistema=e.sistema, repeticao=e.repeticao,
            )
            for e in execucoes
        ],
        ignore_index=True,
    )
    frentes.to_csv(SAIDA / "fronteiras_finais.csv", index=False)

    print("3. estatística")
    resumo = resumo_por_config(df)
    kw = kruskal_por_indicador(df)
    pares = pares_por_indicador(df)
    dunn_bh = dunn_por_indicador(df)
    fat = fatores_por_indicador(df)
    rank = ranking(df)

    resumo.to_csv(SAIDA / "resumo_por_config.csv", index=False)
    kw.to_csv(SAIDA / "testes" / "kruskal_wallis.csv", index=False)
    pares.to_csv(SAIDA / "testes" / "pares_wilcoxon_holm.csv", index=False)
    dunn_bh.to_csv(SAIDA / "testes" / "pares_dunn_bh.csv", index=False)
    fat.to_csv(SAIDA / "testes" / "fatores_wilcoxon_holm.csv", index=False)
    rank.to_csv(SAIDA / "ranking_configs.csv", index=False)

    print("4. tabelas em LaTeX")
    for sistema in SISTEMAS:
        (SAIDA / "tabelas" / f"indicadores_{sistema}.tex").write_text(
            tex_resumo(resumo, sistema), encoding="utf-8"
        )
    (SAIDA / "tabelas" / "kruskal.tex").write_text(tex_kruskal(kw), encoding="utf-8")
    (SAIDA / "tabelas" / "dunn.tex").write_text(tex_dunn(dunn_bh), encoding="utf-8")
    (SAIDA / "tabelas" / "fatores.tex").write_text(tex_fatores(fat), encoding="utf-8")

    print("5. figuras")
    figura_boxplots(df, SAIDA / "figuras")
    figura_evolucao(evolucao, SAIDA / "figuras")

    # ---- o que o artigo precisa ler em voz alta -----------------------------
    print("\n=== Kruskal-Wallis (8 configurações) ===")
    print(kw.to_string(index=False, float_format=lambda v: f"{v:.4f}"))

    print("\n=== Fatores isolados: o que foi significativo ===")
    vencedores = fat[fat.significativo]
    if vencedores.empty:
        print("  nenhum fator significativo após Holm")
    else:
        print(
            vencedores[
                ["sistema", "indicador", "fator", "nivel_a", "nivel_b",
                 "mediana_a", "mediana_b", "p_holm", "a12", "magnitude"]
            ].to_string(index=False, float_format=lambda v: f"{v:.4f}")
        )

    print("\n=== Dunn + BH: pares significativos (pós-hoc do pacote dos professores) ===")
    sig_dunn = dunn_bh[dunn_bh.significativo]
    for sistema in SISTEMAS:
        for rotulo, _ in INDICADORES.values():
            bloco = sig_dunn[(sig_dunn.sistema == sistema) & (sig_dunn.indicador == rotulo)]
            pares_txt = ", ".join(f"{r.melhor}>{r.b if r.melhor == r.a else r.a}" for r in bloco.itertuples())
            print(f"  {sistema:17} {rotulo:10} {len(bloco):2} pares  {pares_txt}")

    print("\n=== Pares significativos após Wilcoxon par a par + Holm ===")
    sig = pares[pares.significativo]
    print("  nenhum" if sig.empty else sig.to_string(index=False))

    print("\n=== Ranking por posto médio (menor = melhor) ===")
    print(rank.to_string(index=False, float_format=lambda v: f"{v:.2f}"))

    print(f"\nTudo em {SAIDA}")


if __name__ == "__main__":
    main()
