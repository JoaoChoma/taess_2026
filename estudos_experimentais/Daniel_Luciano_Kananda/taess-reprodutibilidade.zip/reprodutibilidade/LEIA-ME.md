# Reprodutibilidade: artigo TAES II, persona P2-Systematic-Decoupler

Este pacote regenera, a partir dos dados brutos, todas as tabelas, figuras e
números do artigo "Otimização da Modernização de Sistemas Legados para
Arquiteturas de Microsserviços".

## Como rodar

Precisa de Python 3.11 ou mais novo. Um comando faz tudo e leva cerca de um minuto:

```sh
sh reproduzir.sh
```

O script cria um ambiente virtual em `.venv`, instala as versões fixadas em
`requirements.txt` e roda os três scripts na ordem. Tudo é gravado em `saida/`.
Nenhum script usa números aleatórios, então duas rodadas dão o mesmo resultado.

## Conteúdo

| Arquivo | O que é |
|---|---|
| `dados/persona_2/` | Entrada: os 80 zips exportados pela i-toMicroservices (8 configurações x 2 sistemas x 5 repetições) e, em `analise/`, os indicadores HV, IGD+ e ED calculados pelos professores, mais a geração 0 |
| `pipeline.py` | Indicadores por execução, testes estatísticos (Kruskal-Wallis, Dunn com BH, Wilcoxon com Holm, Â12), boxplots e evolução do fitness |
| `numeros_do_texto.py` | Tabelas e números que o artigo calcula a partir dos artefatos: sistemas, ordem de execução, ambiente, qualidade arquitetural, interação, cardinalidade, reúso, estatística descritiva, Shapiro-Wilk e Levene |
| `graficos_fig4.py` | Coordenadas paralelas das fronteiras finais. Script da Kananda, com rótulos em português e a divisão penalty e kill |
| `requirements.txt` | numpy 2.5.4, scipy 1.18.1, pandas 3.1.1, matplotlib 3.11.2 (testado com Python 3.14.7) |

## Onde está cada elemento do artigo

| No artigo | Script | Arquivo gerado |
|---|---|---|
| Tabela I, características dos sistemas | `numeros_do_texto.py` | `saida/numeros_do_texto/sistemas.csv` |
| Seção 3.2, faixa de tamanho (1,4 a 20,4 e 4,5 a 67,8) | `numeros_do_texto.py` | `arquitetural.csv`, colunas `faixa_min` e `faixa_max` |
| Seção 3.2, tabela da ordem de execução | `numeros_do_texto.py` | `ordem_execucao.csv` |
| Seção 3.2, ambiente e critério de parada | `numeros_do_texto.py` | `ambiente.csv` |
| Seção 3.2, tempos (25 h, médias 949 s e 1.315 s, medianas 612 s e 987 s) | `numeros_do_texto.py` | `tempos.csv` |
| Figuras de coordenadas paralelas, penalty e kill | `graficos_fig4.py` | `saida/figuras/fig4/<sistema>_fig4_{penalty,kill}.pdf` |
| Seção 4, medianas penalty x kill nas fronteiras | `numeros_do_texto.py` | `penalty_kill.csv` |
| Seção 4, variação do reúso | `numeros_do_texto.py` | `reuso.csv` |
| Figuras de evolução do fitness e valores citados | `pipeline.py` | `saida/figuras/evolucao_<sistema>.pdf`, `saida/evolucao_fitness.csv` |
| Tabela IV, qualidade arquitetural | `numeros_do_texto.py` | `arquitetural.csv`, `tabelas/arquitetural.tex` |
| Seção 4.2, cardinalidade e duplicatas | `numeros_do_texto.py` | `cardinalidade.csv` |
| Tabelas descritivas da Seção 4.3 | `numeros_do_texto.py` | `descritiva_indicadores.csv` |
| Shapiro-Wilk e Levene, no texto e no apêndice | `numeros_do_texto.py` | `shapiro_levene.csv` |
| Boxplots dos quatro indicadores | `pipeline.py` | `saida/figuras/boxplots_<sistema>.pdf` |
| Tabela de Kruskal-Wallis | `pipeline.py` | `saida/tabelas/kruskal.tex` |
| Tabela consolidada dos pós-hoc de Dunn | `pipeline.py` | `saida/tabelas/dunn.tex`, `saida/testes/pares_dunn_bh.csv` |
| Tabela do efeito de cada fator | `pipeline.py` | `saida/tabelas/fatores.tex` |
| Tabela de conformidade da interação | `numeros_do_texto.py` | `interacao.csv`, `tabelas/interacao.tex` |
| Seção 4.4, escolhas de candidatos (83 índices, 7 vezes o primeiro) | `numeros_do_texto.py` | `escolhas.csv` |
| Apêndice, A12 e Dunn por par | `pipeline.py` | `saida/testes/pares_dunn_bh.csv` |

Os arquivos `.tex` gerados trazem só as linhas de dados. O cabeçalho, a legenda
e a nota de cada tabela estão no artigo.

## Convenções

- Os cinco objetivos são minimizados. A ferramenta já exporta coesão,
  funcionalidade e reúso invertidos.
- No HV, maior é melhor. No IGD+ e na ED, menor é melhor.
- O Â12 está orientado. Acima de 0,5 favorece sempre o primeiro grupo.
- O Levene usa o centro na mediana, que é o padrão do SciPy.
- O tamanho de um microsserviço conta os elementos do grafo como a ferramenta
  conta, incluindo o nó sintético de entrada `_star_t_`. A faixa usa a mesma base.
- Os participantes aparecem anonimizados como A, B e C, na ordem em que começaram.

## O que este pacote não reproduz

Os gráficos individuais por indicador do apêndice foram feitos com um script da
Kananda que não está aqui. Os números desses gráficos são os mesmos de
`descritiva_indicadores.csv`.
