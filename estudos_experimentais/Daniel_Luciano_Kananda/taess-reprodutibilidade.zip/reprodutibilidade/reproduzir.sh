#!/bin/sh
# Regenera todas as tabelas, figuras e números do artigo a partir dos dados brutos.
# Uso: sh reproduzir.sh        (precisa de python3 >= 3.11)
set -e
cd "$(dirname "$0")"
[ -d .venv ] || { python3 -m venv .venv && .venv/bin/pip install -q -r requirements.txt; }
.venv/bin/python pipeline.py
mkdir -p saida/numeros_do_texto && .venv/bin/python numeros_do_texto.py > saida/numeros_do_texto/resumo.txt
.venv/bin/python graficos_fig4.py dados/persona_2 saida/figuras/fig4
echo "Pronto: tudo em saida/"
