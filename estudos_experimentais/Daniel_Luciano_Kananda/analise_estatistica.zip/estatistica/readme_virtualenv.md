# Instalação do ambiente virtual

Obs.: usar wsl2 do windows

## 1. Verificar se o uv está instalado

Execute:

```
uv --version
```

Se aparecer uma versão, podemos continuar. Caso contrário, instale o uv no Windows com:
```
winget install --id astral-sh.uv -e
```

Depois, reabra o terminal do VS Code.

## 2. Criar o ambiente virtual
Na pasta do projeto:
```
uv python install 3.11
uv venv --python 3.11
```

Isso criará a pasta .venv dentro do projeto, utilizando Python 3.11.

## 3. Instalar as dependências
```
uv pip install --python .venv/bin/python numpy pandas scipy matplotlib ipykernel
```

Não é necessário ativar o ambiente virtual para executar esse comando.

## 4. Configurar o VS Code
Abra o arquivo .ipynb e, no canto superior direito:
1. Clique em Select Kernel.
2. Escolha Python Environments.
3. Selecione o Python localizado em ``.venv/bin/python``

> Caso não apareça

Se o VS Code estiver aberto no Windows, esse ambiente não aparecerá como um Python utilizável.

Faça nesta ordem:
1. Salve o notebook com Ctrl + S.
2. Observe o canto inferior esquerdo do VS Code. Se não aparecer WSL: Ubuntu ou outra distribuição, pressione Ctrl + Shift + P e escolha:
   WSL: Reopen Folder in WSL.
3. Após reabrir, volte ao notebook e clique em:
   Python 3.11.9 → Select Another Kernel → Python Environments.
4. Procure o ambiente .venv, possivelmente identificado como resultados.
