# Tabelas LaTeX conferidas

Copie de tabelas.tex os ambientes table necessários. Não copie main.tex para o artigo: ele serve apenas à prévia. Dependência: graphicx.

## Mapeamento

- 1: nsgaiii__elit_on__penalty
- 2: nsgaiii__elit_off__penalty
- 3: rnsgaiii__elit_on__penalty
- 4: rnsgaiii__elit_off__penalty
- 5: nsgaiii__elit_on__kill
- 6: nsgaiii__elit_off__kill
- 7: rnsgaiii__elit_on__kill
- 8: rnsgaiii__elit_off__kill

## Conferência

jpetstore_hv: 8 descritivas verificadas contra CSV; 28 A12 recalculados; pós-hoc: 28 pares, 11 significativos.
jpetstore_igd_plus: 8 descritivas verificadas contra CSV; 28 A12 recalculados; pós-hoc: 28 pares, 11 significativos.
jpetstore_ed_media: 8 descritivas verificadas contra CSV; 28 A12 recalculados; pós-hoc: 0 pares, 0 significativos.
jpetstore_ed_min: 8 descritivas verificadas contra CSV; 28 A12 recalculados; pós-hoc: 28 pares, 0 significativos.
spring-petclinic_hv: 8 descritivas verificadas contra CSV; 28 A12 recalculados; pós-hoc: 28 pares, 11 significativos.
spring-petclinic_igd_plus: 8 descritivas verificadas contra CSV; 28 A12 recalculados; pós-hoc: 28 pares, 10 significativos.
spring-petclinic_ed_media: 8 descritivas verificadas contra CSV; 28 A12 recalculados; pós-hoc: 28 pares, 9 significativos.
spring-petclinic_ed_min: 8 descritivas verificadas contra CSV; 28 A12 recalculados; pós-hoc: 28 pares, 7 significativos.

## Correções e decisões
- Mínimos e máximos do HV do PetClinic foram associados aos IDs corretos a partir do CSV.
- jPetStore / ED mínima: ANOVA significativa; pós-hoc Tukey seguido de BH sem pares significativos. A tabela foi recuperada pelos dados.
- jPetStore / ED média: pós-hoc não realizado, pois ANOVA não significativa.
- A e B ordenados por ID numérico. Quando necessário, os sinais de z/diferença e a orientação de A12 foram invertidos de forma consistente.
- A12: corrigida a classificação de valores de fronteira numérica (por exemplo, 0,56 é desprezível, pois a distância a 0,50 é exatamente 0,06). O código original pode classificar 0,56 como pequena por arredondamento de ponto flutuante. Os valores de A12 não foram alterados.
- p-valores não são arredondados para zero; a decisão de significância usa o valor integral. Não há correção conjunta entre indicadores.
- 47 labels únicos, no padrão tab:sistema-indicador-funcao.

## Fontes e rastreabilidade

- C:\workspace_uem\taessii-trabalho\resultados\analise\P2-Systematic-Decoupler_jpetstore.csv
  SHA256: 87f53b35a165609d332abd6b4b687d1475e7322f08eeb20a992132b12a19d7d2
- C:\workspace_uem\taessii-trabalho\resultados\analise\P2-Systematic-Decoupler_spring-petclinic.csv
  SHA256: 7833daff5b6a07451a6d52226c01c8dcfd59c29cf50c453263f84ba9b7fbe030
- C:\workspace_uem\taessii-trabalho\resultados\analise_estatistica.ipynb
  SHA256: 62310c380c60bd6e9e6f82749d73d678650195a9ceb2ab25d1ab22d831a37064

## Labels

- `tab:jpetstore-hv-analise_descritiva`
- `tab:jpetstore-hv-shapiro_wilk`
- `tab:jpetstore-hv-levene`
- `tab:jpetstore-hv-teste_global`
- `tab:jpetstore-hv-pos_hoc`
- `tab:jpetstore-hv-a12`
- `tab:jpetstore-igd_plus-analise_descritiva`
- `tab:jpetstore-igd_plus-shapiro_wilk`
- `tab:jpetstore-igd_plus-levene`
- `tab:jpetstore-igd_plus-teste_global`
- `tab:jpetstore-igd_plus-pos_hoc`
- `tab:jpetstore-igd_plus-a12`
- `tab:jpetstore-ed_media-analise_descritiva`
- `tab:jpetstore-ed_media-shapiro_wilk`
- `tab:jpetstore-ed_media-levene`
- `tab:jpetstore-ed_media-teste_global`
- `tab:jpetstore-ed_media-a12`
- `tab:jpetstore-ed_min-analise_descritiva`
- `tab:jpetstore-ed_min-shapiro_wilk`
- `tab:jpetstore-ed_min-levene`
- `tab:jpetstore-ed_min-teste_global`
- `tab:jpetstore-ed_min-pos_hoc`
- `tab:jpetstore-ed_min-a12`
- `tab:spring-petclinic-hv-analise_descritiva`
- `tab:spring-petclinic-hv-shapiro_wilk`
- `tab:spring-petclinic-hv-levene`
- `tab:spring-petclinic-hv-teste_global`
- `tab:spring-petclinic-hv-pos_hoc`
- `tab:spring-petclinic-hv-a12`
- `tab:spring-petclinic-igd_plus-analise_descritiva`
- `tab:spring-petclinic-igd_plus-shapiro_wilk`
- `tab:spring-petclinic-igd_plus-levene`
- `tab:spring-petclinic-igd_plus-teste_global`
- `tab:spring-petclinic-igd_plus-pos_hoc`
- `tab:spring-petclinic-igd_plus-a12`
- `tab:spring-petclinic-ed_media-analise_descritiva`
- `tab:spring-petclinic-ed_media-shapiro_wilk`
- `tab:spring-petclinic-ed_media-levene`
- `tab:spring-petclinic-ed_media-teste_global`
- `tab:spring-petclinic-ed_media-pos_hoc`
- `tab:spring-petclinic-ed_media-a12`
- `tab:spring-petclinic-ed_min-analise_descritiva`
- `tab:spring-petclinic-ed_min-shapiro_wilk`
- `tab:spring-petclinic-ed_min-levene`
- `tab:spring-petclinic-ed_min-teste_global`
- `tab:spring-petclinic-ed_min-pos_hoc`
- `tab:spring-petclinic-ed_min-a12`